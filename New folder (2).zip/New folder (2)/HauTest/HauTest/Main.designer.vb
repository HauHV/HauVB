﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Main
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.BarManager1 = New DevExpress.XtraBars.BarManager(Me.components)
        Me.Bar1 = New DevExpress.XtraBars.Bar
        Me.BarButtonItem6 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem9 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem10 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem11 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem21 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem12 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem13 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem14 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem15 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem16 = New DevExpress.XtraBars.BarButtonItem
        Me.Bar2 = New DevExpress.XtraBars.Bar
        Me.BarSubItem1 = New DevExpress.XtraBars.BarSubItem
        Me.BarSubItem3 = New DevExpress.XtraBars.BarSubItem
        Me.BarButtonItem2 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem3 = New DevExpress.XtraBars.BarButtonItem
        Me.BarSubItem4 = New DevExpress.XtraBars.BarSubItem
        Me.BarSubItem5 = New DevExpress.XtraBars.BarSubItem
        Me.BarSubItem6 = New DevExpress.XtraBars.BarSubItem
        Me.BarSubItem7 = New DevExpress.XtraBars.BarSubItem
        Me.BarSubItem10 = New DevExpress.XtraBars.BarSubItem
        Me.btnKH = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem17 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem18 = New DevExpress.XtraBars.BarButtonItem
        Me.btnNhapChungTu = New DevExpress.XtraBars.BarButtonItem
        Me.BarSubItem11 = New DevExpress.XtraBars.BarSubItem
        Me.btnKeBanHang = New DevExpress.XtraBars.BarButtonItem
        Me.btnKeMuaHang = New DevExpress.XtraBars.BarButtonItem
        Me.btnXNT1 = New DevExpress.XtraBars.BarButtonItem
        Me.btnXNT2 = New DevExpress.XtraBars.BarButtonItem
        Me.btnHangTonKho = New DevExpress.XtraBars.BarButtonItem
        Me.BarSubItem8 = New DevExpress.XtraBars.BarSubItem
        Me.BarButtonItem4 = New DevExpress.XtraBars.BarButtonItem
        Me.Bar3 = New DevExpress.XtraBars.Bar
        Me.BarStaticItem1 = New DevExpress.XtraBars.BarStaticItem
        Me.BarStaticItem3 = New DevExpress.XtraBars.BarStaticItem
        Me.BarStaticItem4 = New DevExpress.XtraBars.BarStaticItem
        Me.BarStaticItem5 = New DevExpress.XtraBars.BarStaticItem
        Me.barDockControlTop = New DevExpress.XtraBars.BarDockControl
        Me.barDockControlBottom = New DevExpress.XtraBars.BarDockControl
        Me.barDockControlLeft = New DevExpress.XtraBars.BarDockControl
        Me.barDockControlRight = New DevExpress.XtraBars.BarDockControl
        Me.BarSubItem2 = New DevExpress.XtraBars.BarSubItem
        Me.BarButtonItem1 = New DevExpress.XtraBars.BarButtonItem
        Me.BarEditItem1 = New DevExpress.XtraBars.BarEditItem
        Me.RepositoryItemButtonEdit1 = New DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit
        Me.BarLargeButtonItem1 = New DevExpress.XtraBars.BarLargeButtonItem
        Me.BarStaticItem2 = New DevExpress.XtraBars.BarStaticItem
        Me.BarSubItem9 = New DevExpress.XtraBars.BarSubItem
        Me.btnBan = New DevExpress.XtraBars.BarButtonItem
        Me.GridControl1 = New DevExpress.XtraGrid.GridControl
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.btnDong = New DevExpress.XtraEditors.SimpleButton
        Me.btnSua = New DevExpress.XtraEditors.SimpleButton
        Me.btnXoa = New DevExpress.XtraEditors.SimpleButton
        Me.btnThem = New DevExpress.XtraEditors.SimpleButton
        Me.btnXem = New DevExpress.XtraEditors.SimpleButton
        Me.SimpleButton11 = New DevExpress.XtraEditors.SimpleButton
        Me.SimpleButton13 = New DevExpress.XtraEditors.SimpleButton
        Me.SimpleButton14 = New DevExpress.XtraEditors.SimpleButton
        Me.SimpleButton15 = New DevExpress.XtraEditors.SimpleButton
        Me.BarButtonItem5 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem7 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem8 = New DevExpress.XtraBars.BarButtonItem
        Me.BarButtonItem20 = New DevExpress.XtraBars.BarButtonItem
        CType(Me.BarManager1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.RepositoryItemButtonEdit1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'BarManager1
        '
        Me.BarManager1.Bars.AddRange(New DevExpress.XtraBars.Bar() {Me.Bar1, Me.Bar2, Me.Bar3})
        Me.BarManager1.DockControls.Add(Me.barDockControlTop)
        Me.BarManager1.DockControls.Add(Me.barDockControlBottom)
        Me.BarManager1.DockControls.Add(Me.barDockControlLeft)
        Me.BarManager1.DockControls.Add(Me.barDockControlRight)
        Me.BarManager1.Form = Me
        Me.BarManager1.Items.AddRange(New DevExpress.XtraBars.BarItem() {Me.BarSubItem1, Me.BarSubItem2, Me.BarSubItem3, Me.BarSubItem4, Me.BarSubItem5, Me.BarButtonItem1, Me.BarEditItem1, Me.BarButtonItem2, Me.BarButtonItem3, Me.BarSubItem6, Me.BarSubItem7, Me.BarSubItem8, Me.BarButtonItem4, Me.BarButtonItem6, Me.BarLargeButtonItem1, Me.BarStaticItem1, Me.BarButtonItem9, Me.BarButtonItem10, Me.BarButtonItem11, Me.BarButtonItem12, Me.BarButtonItem13, Me.BarButtonItem14, Me.BarButtonItem15, Me.BarButtonItem16, Me.BarStaticItem2, Me.BarStaticItem3, Me.BarStaticItem4, Me.BarStaticItem5, Me.BarSubItem9, Me.btnBan, Me.BarSubItem10, Me.btnKH, Me.BarSubItem11, Me.btnKeBanHang, Me.btnKeMuaHang, Me.btnXNT1, Me.btnXNT2, Me.btnHangTonKho, Me.BarButtonItem17, Me.BarButtonItem18, Me.btnNhapChungTu, Me.BarButtonItem21})
        Me.BarManager1.MainMenu = Me.Bar2
        Me.BarManager1.MaxItemId = 47
        Me.BarManager1.RepositoryItems.AddRange(New DevExpress.XtraEditors.Repository.RepositoryItem() {Me.RepositoryItemButtonEdit1})
        Me.BarManager1.StatusBar = Me.Bar3
        '
        'Bar1
        '
        Me.Bar1.BarName = "Tools"
        Me.Bar1.DockCol = 0
        Me.Bar1.DockRow = 1
        Me.Bar1.DockStyle = DevExpress.XtraBars.BarDockStyle.Top
        Me.Bar1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, Me.BarButtonItem6, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph), New DevExpress.XtraBars.LinkPersistInfo(Me.BarButtonItem9), New DevExpress.XtraBars.LinkPersistInfo(Me.BarButtonItem10), New DevExpress.XtraBars.LinkPersistInfo(Me.BarButtonItem11), New DevExpress.XtraBars.LinkPersistInfo(Me.BarButtonItem21), New DevExpress.XtraBars.LinkPersistInfo(Me.BarButtonItem12), New DevExpress.XtraBars.LinkPersistInfo(Me.BarButtonItem13), New DevExpress.XtraBars.LinkPersistInfo(Me.BarButtonItem14), New DevExpress.XtraBars.LinkPersistInfo(Me.BarButtonItem15), New DevExpress.XtraBars.LinkPersistInfo(Me.BarButtonItem16)})
        Me.Bar1.OptionsBar.AllowCollapse = True
        Me.Bar1.OptionsBar.AllowDelete = True
        Me.Bar1.OptionsBar.AllowQuickCustomization = False
        Me.Bar1.OptionsBar.DisableCustomization = True
        Me.Bar1.OptionsBar.UseWholeRow = True
        Me.Bar1.Text = "Tools"
        '
        'BarButtonItem6
        '
        Me.BarButtonItem6.Caption = "Bảng kê bán hàng"
        Me.BarButtonItem6.Id = 17
        Me.BarButtonItem6.ImageIndex = 1
        Me.BarButtonItem6.ImageIndexDisabled = 1
        Me.BarButtonItem6.Name = "BarButtonItem6"
        '
        'BarButtonItem9
        '
        Me.BarButtonItem9.Caption = "Bảng kê mua hàng"
        Me.BarButtonItem9.CausesValidation = True
        Me.BarButtonItem9.Id = 20
        Me.BarButtonItem9.Name = "BarButtonItem9"
        Me.BarButtonItem9.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph
        '
        'BarButtonItem10
        '
        Me.BarButtonItem10.Caption = "Báo cáo XNT 1"
        Me.BarButtonItem10.Id = 21
        Me.BarButtonItem10.Name = "BarButtonItem10"
        Me.BarButtonItem10.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph
        '
        'BarButtonItem11
        '
        Me.BarButtonItem11.Caption = "Báo cáo XNT 2"
        Me.BarButtonItem11.Id = 22
        Me.BarButtonItem11.Name = "BarButtonItem11"
        Me.BarButtonItem11.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph
        '
        'BarButtonItem21
        '
        Me.BarButtonItem21.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left
        Me.BarButtonItem21.Caption = "Hàng hóa tồn kho"
        Me.BarButtonItem21.Id = 46
        Me.BarButtonItem21.Name = "BarButtonItem21"
        '
        'BarButtonItem12
        '
        Me.BarButtonItem12.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
        Me.BarButtonItem12.Caption = "BarButtonItem12"
        Me.BarButtonItem12.CausesValidation = True
        Me.BarButtonItem12.Glyph = Global.HauTest.My.Resources.Resources.CMD_INFOR01_24
        Me.BarButtonItem12.Id = 23
        Me.BarButtonItem12.Name = "BarButtonItem12"
        Me.BarButtonItem12.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu
        '
        'BarButtonItem13
        '
        Me.BarButtonItem13.Caption = "BarButtonItem13"
        Me.BarButtonItem13.Glyph = Global.HauTest.My.Resources.Resources.iItemList13_24
        Me.BarButtonItem13.Id = 24
        Me.BarButtonItem13.Name = "BarButtonItem13"
        Me.BarButtonItem13.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu
        '
        'BarButtonItem14
        '
        Me.BarButtonItem14.Caption = "BarButtonItem14"
        Me.BarButtonItem14.Glyph = Global.HauTest.My.Resources.Resources.CMD_HELP01_24
        Me.BarButtonItem14.Id = 25
        Me.BarButtonItem14.Name = "BarButtonItem14"
        Me.BarButtonItem14.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu
        '
        'BarButtonItem15
        '
        Me.BarButtonItem15.Caption = "admin"
        Me.BarButtonItem15.Glyph = Global.HauTest.My.Resources.Resources.CMD_LOGOFF01_24
        Me.BarButtonItem15.Id = 26
        Me.BarButtonItem15.Name = "BarButtonItem15"
        Me.BarButtonItem15.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph
        '
        'BarButtonItem16
        '
        Me.BarButtonItem16.Glyph = Global.HauTest.My.Resources.Resources.CMD_EXIT01_24
        Me.BarButtonItem16.Id = 27
        Me.BarButtonItem16.Name = "BarButtonItem16"
        Me.BarButtonItem16.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu
        '
        'Bar2
        '
        Me.Bar2.BarName = "Main menu"
        Me.Bar2.DockCol = 0
        Me.Bar2.DockRow = 0
        Me.Bar2.DockStyle = DevExpress.XtraBars.BarDockStyle.Top
        Me.Bar2.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.BarSubItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.BarSubItem6), New DevExpress.XtraBars.LinkPersistInfo(Me.BarSubItem7), New DevExpress.XtraBars.LinkPersistInfo(Me.BarSubItem8), New DevExpress.XtraBars.LinkPersistInfo(Me.BarButtonItem4)})
        Me.Bar2.OptionsBar.MultiLine = True
        Me.Bar2.OptionsBar.UseWholeRow = True
        Me.Bar2.Text = "Main menu"
        '
        'BarSubItem1
        '
        Me.BarSubItem1.Caption = "Tài chính kế toán"
        Me.BarSubItem1.Id = 0
        Me.BarSubItem1.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.BarSubItem3), New DevExpress.XtraBars.LinkPersistInfo(Me.BarSubItem4), New DevExpress.XtraBars.LinkPersistInfo(Me.BarSubItem5)})
        Me.BarSubItem1.Name = "BarSubItem1"
        '
        'BarSubItem3
        '
        Me.BarSubItem3.Caption = "Danh mục"
        Me.BarSubItem3.Id = 5
        Me.BarSubItem3.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(DevExpress.XtraBars.BarLinkUserDefines.PaintStyle, Me.BarButtonItem2, DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph), New DevExpress.XtraBars.LinkPersistInfo(Me.BarButtonItem3)})
        Me.BarSubItem3.Name = "BarSubItem3"
        '
        'BarButtonItem2
        '
        Me.BarButtonItem2.Caption = "Tài khoản"
        Me.BarButtonItem2.Id = 10
        Me.BarButtonItem2.Name = "BarButtonItem2"
        '
        'BarButtonItem3
        '
        Me.BarButtonItem3.Caption = "Tài sản"
        Me.BarButtonItem3.Id = 11
        Me.BarButtonItem3.Name = "BarButtonItem3"
        '
        'BarSubItem4
        '
        Me.BarSubItem4.Caption = "Thiết lập"
        Me.BarSubItem4.Id = 6
        Me.BarSubItem4.Name = "BarSubItem4"
        '
        'BarSubItem5
        '
        Me.BarSubItem5.Caption = "Nhập liệu"
        Me.BarSubItem5.Id = 7
        Me.BarSubItem5.Name = "BarSubItem5"
        '
        'BarSubItem6
        '
        Me.BarSubItem6.Caption = "Hàng hóa đầu vào"
        Me.BarSubItem6.Id = 12
        Me.BarSubItem6.Name = "BarSubItem6"
        '
        'BarSubItem7
        '
        Me.BarSubItem7.Caption = "Hàng hóa trong kho"
        Me.BarSubItem7.Id = 13
        Me.BarSubItem7.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.BarSubItem10), New DevExpress.XtraBars.LinkPersistInfo(Me.BarSubItem11)})
        Me.BarSubItem7.Name = "BarSubItem7"
        '
        'BarSubItem10
        '
        Me.BarSubItem10.Caption = "Nhập liệu"
        Me.BarSubItem10.Id = 34
        Me.BarSubItem10.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.btnKH), New DevExpress.XtraBars.LinkPersistInfo(Me.BarButtonItem17), New DevExpress.XtraBars.LinkPersistInfo(Me.BarButtonItem18), New DevExpress.XtraBars.LinkPersistInfo(Me.btnNhapChungTu)})
        Me.BarSubItem10.Name = "BarSubItem10"
        '
        'btnKH
        '
        Me.btnKH.Caption = "Khách Hàng"
        Me.btnKH.Id = 35
        Me.btnKH.Name = "btnKH"
        '
        'BarButtonItem17
        '
        Me.BarButtonItem17.Caption = "Hàng Hóa"
        Me.BarButtonItem17.Id = 42
        Me.BarButtonItem17.Name = "BarButtonItem17"
        '
        'BarButtonItem18
        '
        Me.BarButtonItem18.Caption = "Kho"
        Me.BarButtonItem18.Id = 43
        Me.BarButtonItem18.Name = "BarButtonItem18"
        '
        'btnNhapChungTu
        '
        Me.btnNhapChungTu.Caption = "Nhập chứng từ"
        Me.btnNhapChungTu.Id = 44
        Me.btnNhapChungTu.Name = "btnNhapChungTu"
        '
        'BarSubItem11
        '
        Me.BarSubItem11.Caption = "Báo cáo"
        Me.BarSubItem11.Id = 36
        Me.BarSubItem11.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.btnKeBanHang), New DevExpress.XtraBars.LinkPersistInfo(Me.btnKeMuaHang), New DevExpress.XtraBars.LinkPersistInfo(Me.btnXNT1), New DevExpress.XtraBars.LinkPersistInfo(Me.btnXNT2), New DevExpress.XtraBars.LinkPersistInfo(Me.btnHangTonKho)})
        Me.BarSubItem11.Name = "BarSubItem11"
        '
        'btnKeBanHang
        '
        Me.btnKeBanHang.Caption = "Bảng kê bán hàng"
        Me.btnKeBanHang.Id = 37
        Me.btnKeBanHang.Name = "btnKeBanHang"
        '
        'btnKeMuaHang
        '
        Me.btnKeMuaHang.Caption = "Bảng kê mua hàng"
        Me.btnKeMuaHang.Id = 38
        Me.btnKeMuaHang.Name = "btnKeMuaHang"
        '
        'btnXNT1
        '
        Me.btnXNT1.Caption = "Báo cáo X-N-T 1"
        Me.btnXNT1.Id = 39
        Me.btnXNT1.Name = "btnXNT1"
        '
        'btnXNT2
        '
        Me.btnXNT2.Caption = "Báo cáo X-N-T 2"
        Me.btnXNT2.Id = 40
        Me.btnXNT2.Name = "btnXNT2"
        '
        'btnHangTonKho
        '
        Me.btnHangTonKho.Caption = "Hàng hóa tồn kho"
        Me.btnHangTonKho.Id = 41
        Me.btnHangTonKho.Name = "btnHangTonKho"
        '
        'BarSubItem8
        '
        Me.BarSubItem8.Caption = "Hàng hóa đầu ra"
        Me.BarSubItem8.Id = 14
        Me.BarSubItem8.Name = "BarSubItem8"
        '
        'BarButtonItem4
        '
        Me.BarButtonItem4.Caption = "Hệ thống"
        Me.BarButtonItem4.Id = 15
        Me.BarButtonItem4.Name = "BarButtonItem4"
        '
        'Bar3
        '
        Me.Bar3.BarName = "Status bar"
        Me.Bar3.CanDockStyle = DevExpress.XtraBars.BarCanDockStyle.Bottom
        Me.Bar3.DockCol = 0
        Me.Bar3.DockRow = 0
        Me.Bar3.DockStyle = DevExpress.XtraBars.BarDockStyle.Bottom
        Me.Bar3.LinksPersistInfo.AddRange(New DevExpress.XtraBars.LinkPersistInfo() {New DevExpress.XtraBars.LinkPersistInfo(Me.BarStaticItem1), New DevExpress.XtraBars.LinkPersistInfo(Me.BarStaticItem3), New DevExpress.XtraBars.LinkPersistInfo(Me.BarStaticItem4), New DevExpress.XtraBars.LinkPersistInfo(Me.BarStaticItem5)})
        Me.Bar3.OptionsBar.AllowQuickCustomization = False
        Me.Bar3.OptionsBar.DisableCustomization = True
        Me.Bar3.OptionsBar.UseWholeRow = True
        Me.Bar3.Text = "Status bar"
        '
        'BarStaticItem1
        '
        Me.BarStaticItem1.Caption = "fsfsdfsd"
        Me.BarStaticItem1.Glyph = Global.HauTest.My.Resources.Resources.iLogo_52_24
        Me.BarStaticItem1.Id = 19
        Me.BarStaticItem1.Name = "BarStaticItem1"
        Me.BarStaticItem1.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionInMenu
        Me.BarStaticItem1.TextAlignment = System.Drawing.StringAlignment.Near
        '
        'BarStaticItem3
        '
        Me.BarStaticItem3.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.BarStaticItem3.Appearance.Options.UseFont = True
        Me.BarStaticItem3.Appearance.Options.UseTextOptions = True
        Me.BarStaticItem3.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
        Me.BarStaticItem3.Caption = "Công Ty Cổ Phần Công Nghệ Tin Học H.T.L" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Trụ sở chính: 338/30 - Nơ Trang Long, P." & _
            "13, Q.BT, Tp.HCM"
        Me.BarStaticItem3.Id = 29
        Me.BarStaticItem3.Name = "BarStaticItem3"
        Me.BarStaticItem3.TextAlignment = System.Drawing.StringAlignment.Near
        '
        'BarStaticItem4
        '
        Me.BarStaticItem4.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.BarStaticItem4.Appearance.Options.UseFont = True
        Me.BarStaticItem4.AutoSize = DevExpress.XtraBars.BarStaticItemSize.Spring
        Me.BarStaticItem4.Caption = "Nhấn F5 để cập nhật dữ liệu mới nhất"
        Me.BarStaticItem4.Id = 30
        Me.BarStaticItem4.Name = "BarStaticItem4"
        Me.BarStaticItem4.TextAlignment = System.Drawing.StringAlignment.Near
        Me.BarStaticItem4.Width = 32
        '
        'BarStaticItem5
        '
        Me.BarStaticItem5.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right
        Me.BarStaticItem5.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.BarStaticItem5.Appearance.Options.UseFont = True
        Me.BarStaticItem5.Appearance.Options.UseTextOptions = True
        Me.BarStaticItem5.Appearance.TextOptions.WordWrap = DevExpress.Utils.WordWrap.Wrap
        Me.BarStaticItem5.Caption = "serverhtl (192.168.1.252)" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "DAS6HNHAN2016New"
        Me.BarStaticItem5.Id = 31
        Me.BarStaticItem5.Name = "BarStaticItem5"
        Me.BarStaticItem5.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.Caption
        Me.BarStaticItem5.TextAlignment = System.Drawing.StringAlignment.Near
        '
        'barDockControlTop
        '
        Me.barDockControlTop.Appearance.BackColor = System.Drawing.Color.Transparent
        Me.barDockControlTop.Appearance.BackColor2 = System.Drawing.Color.Transparent
        Me.barDockControlTop.Appearance.Options.UseBackColor = True
        Me.barDockControlTop.CausesValidation = False
        Me.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top
        Me.barDockControlTop.Location = New System.Drawing.Point(0, 0)
        Me.barDockControlTop.Size = New System.Drawing.Size(1043, 61)
        '
        'barDockControlBottom
        '
        Me.barDockControlBottom.CausesValidation = False
        Me.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom
        Me.barDockControlBottom.Location = New System.Drawing.Point(0, 689)
        Me.barDockControlBottom.Size = New System.Drawing.Size(1043, 41)
        '
        'barDockControlLeft
        '
        Me.barDockControlLeft.CausesValidation = False
        Me.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left
        Me.barDockControlLeft.Location = New System.Drawing.Point(0, 61)
        Me.barDockControlLeft.Size = New System.Drawing.Size(0, 628)
        '
        'barDockControlRight
        '
        Me.barDockControlRight.CausesValidation = False
        Me.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right
        Me.barDockControlRight.Location = New System.Drawing.Point(1043, 61)
        Me.barDockControlRight.Size = New System.Drawing.Size(0, 628)
        '
        'BarSubItem2
        '
        Me.BarSubItem2.Caption = "BarSubItem2"
        Me.BarSubItem2.Id = 1
        Me.BarSubItem2.Name = "BarSubItem2"
        '
        'BarButtonItem1
        '
        Me.BarButtonItem1.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.BarButtonItem1.Appearance.Options.UseFont = True
        Me.BarButtonItem1.Appearance.Options.UseImage = True
        Me.BarButtonItem1.Caption = "Tài khoản"
        Me.BarButtonItem1.Id = 8
        Me.BarButtonItem1.Name = "BarButtonItem1"
        '
        'BarEditItem1
        '
        Me.BarEditItem1.Caption = "Tài khoản"
        Me.BarEditItem1.Edit = Me.RepositoryItemButtonEdit1
        Me.BarEditItem1.Id = 9
        Me.BarEditItem1.Name = "BarEditItem1"
        '
        'RepositoryItemButtonEdit1
        '
        Me.RepositoryItemButtonEdit1.AutoHeight = False
        Me.RepositoryItemButtonEdit1.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton})
        Me.RepositoryItemButtonEdit1.Name = "RepositoryItemButtonEdit1"
        '
        'BarLargeButtonItem1
        '
        Me.BarLargeButtonItem1.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Left
        Me.BarLargeButtonItem1.Caption = "Chứng từ kho hàng "
        Me.BarLargeButtonItem1.Id = 18
        Me.BarLargeButtonItem1.Name = "BarLargeButtonItem1"
        '
        'BarStaticItem2
        '
        Me.BarStaticItem2.Caption = "Công "
        Me.BarStaticItem2.Id = 28
        Me.BarStaticItem2.Name = "BarStaticItem2"
        Me.BarStaticItem2.TextAlignment = System.Drawing.StringAlignment.Near
        '
        'BarSubItem9
        '
        Me.BarSubItem9.Caption = "Bảng kê bán hàng"
        Me.BarSubItem9.Id = 32
        Me.BarSubItem9.Name = "BarSubItem9"
        '
        'btnBan
        '
        Me.btnBan.Caption = "Bảng kê bán hàng"
        Me.btnBan.Id = 33
        Me.btnBan.Name = "btnBan"
        '
        'GridControl1
        '
        Me.GridControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GridControl1.Location = New System.Drawing.Point(0, 80)
        Me.GridControl1.MainView = Me.GridView1
        Me.GridControl1.MenuManager = Me.BarManager1
        Me.GridControl1.Name = "GridControl1"
        Me.GridControl1.Size = New System.Drawing.Size(1043, 574)
        Me.GridControl1.TabIndex = 4
        Me.GridControl1.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.Appearance.FocusedRow.Options.UseTextOptions = True
        Me.GridView1.Appearance.FocusedRow.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView1.Appearance.HeaderPanel.Options.UseTextOptions = True
        Me.GridView1.Appearance.HeaderPanel.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView1.Appearance.OddRow.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.GridView1.Appearance.OddRow.Options.UseBackColor = True
        Me.GridView1.Appearance.Row.Options.UseTextOptions = True
        Me.GridView1.Appearance.Row.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView1.GridControl = Me.GridControl1
        Me.GridView1.Name = "GridView1"
        '
        'btnDong
        '
        Me.btnDong.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnDong.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnDong.Appearance.Options.UseFont = True
        Me.btnDong.Image = Global.HauTest.My.Resources.Resources.CMD_EXIT01
        Me.btnDong.Location = New System.Drawing.Point(956, 660)
        Me.btnDong.Name = "btnDong"
        Me.btnDong.Size = New System.Drawing.Size(75, 23)
        Me.btnDong.TabIndex = 38
        Me.btnDong.Text = "Đóng"
        '
        'btnSua
        '
        Me.btnSua.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnSua.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnSua.Appearance.Options.UseFont = True
        Me.btnSua.Image = Global.HauTest.My.Resources.Resources.CMD_EDIT01
        Me.btnSua.Location = New System.Drawing.Point(875, 660)
        Me.btnSua.Name = "btnSua"
        Me.btnSua.Size = New System.Drawing.Size(75, 23)
        Me.btnSua.TabIndex = 43
        Me.btnSua.Text = "Sửa"
        '
        'btnXoa
        '
        Me.btnXoa.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnXoa.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnXoa.Appearance.Options.UseFont = True
        Me.btnXoa.Image = Global.HauTest.My.Resources.Resources.CMD_DELETE01
        Me.btnXoa.Location = New System.Drawing.Point(794, 660)
        Me.btnXoa.Name = "btnXoa"
        Me.btnXoa.Size = New System.Drawing.Size(75, 23)
        Me.btnXoa.TabIndex = 44
        Me.btnXoa.Text = "Xóa"
        '
        'btnThem
        '
        Me.btnThem.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnThem.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnThem.Appearance.Options.UseFont = True
        Me.btnThem.Image = Global.HauTest.My.Resources.Resources.CMD_ADD01
        Me.btnThem.Location = New System.Drawing.Point(713, 660)
        Me.btnThem.Name = "btnThem"
        Me.btnThem.Size = New System.Drawing.Size(75, 23)
        Me.btnThem.TabIndex = 45
        Me.btnThem.Text = "Thêm"
        '
        'btnXem
        '
        Me.btnXem.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.btnXem.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnXem.Appearance.Options.UseFont = True
        Me.btnXem.Image = Global.HauTest.My.Resources.Resources.iItemList09_16
        Me.btnXem.Location = New System.Drawing.Point(632, 660)
        Me.btnXem.Name = "btnXem"
        Me.btnXem.Size = New System.Drawing.Size(75, 23)
        Me.btnXem.TabIndex = 46
        Me.btnXem.Text = "Xem"
        '
        'SimpleButton11
        '
        Me.SimpleButton11.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SimpleButton11.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SimpleButton11.Appearance.Options.UseFont = True
        Me.SimpleButton11.Image = Global.HauTest.My.Resources.Resources.CMD_EXCEL01
        Me.SimpleButton11.Location = New System.Drawing.Point(602, 660)
        Me.SimpleButton11.Name = "SimpleButton11"
        Me.SimpleButton11.Size = New System.Drawing.Size(24, 23)
        Me.SimpleButton11.TabIndex = 47
        '
        'SimpleButton13
        '
        Me.SimpleButton13.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.SimpleButton13.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SimpleButton13.Appearance.Options.UseFont = True
        Me.SimpleButton13.Location = New System.Drawing.Point(12, 774)
        Me.SimpleButton13.Name = "SimpleButton13"
        Me.SimpleButton13.Size = New System.Drawing.Size(83, 23)
        Me.SimpleButton13.TabIndex = 53
        Me.SimpleButton13.Text = "Sub mask"
        '
        'SimpleButton14
        '
        Me.SimpleButton14.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.SimpleButton14.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SimpleButton14.Appearance.Options.UseFont = True
        Me.SimpleButton14.Location = New System.Drawing.Point(101, 774)
        Me.SimpleButton14.Name = "SimpleButton14"
        Me.SimpleButton14.Size = New System.Drawing.Size(112, 23)
        Me.SimpleButton14.TabIndex = 54
        Me.SimpleButton14.Text = "Nhập từ tập tin"
        '
        'SimpleButton15
        '
        Me.SimpleButton15.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.SimpleButton15.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SimpleButton15.Appearance.Options.UseFont = True
        Me.SimpleButton15.Location = New System.Drawing.Point(219, 774)
        Me.SimpleButton15.Name = "SimpleButton15"
        Me.SimpleButton15.Size = New System.Drawing.Size(112, 23)
        Me.SimpleButton15.TabIndex = 55
        Me.SimpleButton15.Text = "Xuất ra tập tin"
        '
        'BarButtonItem5
        '
        Me.BarButtonItem5.Caption = "Chứng từ mua hàng"
        Me.BarButtonItem5.Id = 17
        Me.BarButtonItem5.ImageIndex = 1
        Me.BarButtonItem5.ImageIndexDisabled = 1
        Me.BarButtonItem5.Name = "BarButtonItem5"
        '
        'BarButtonItem7
        '
        Me.BarButtonItem7.Caption = "Chứng từ mua hàng"
        Me.BarButtonItem7.Id = 17
        Me.BarButtonItem7.ImageIndex = 1
        Me.BarButtonItem7.ImageIndexDisabled = 1
        Me.BarButtonItem7.Name = "BarButtonItem7"
        '
        'BarButtonItem8
        '
        Me.BarButtonItem8.Caption = "Chứng từ mua hàng"
        Me.BarButtonItem8.Id = 17
        Me.BarButtonItem8.ImageIndex = 1
        Me.BarButtonItem8.ImageIndexDisabled = 1
        Me.BarButtonItem8.Name = "BarButtonItem8"
        '
        'BarButtonItem20
        '
        Me.BarButtonItem20.Caption = "Báo cáo XNT 2"
        Me.BarButtonItem20.Id = 22
        Me.BarButtonItem20.Name = "BarButtonItem20"
        Me.BarButtonItem20.PaintStyle = DevExpress.XtraBars.BarItemPaintStyle.CaptionGlyph
        '
        'Main
        '
        Me.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.Appearance.Options.UseFont = True
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.ClientSize = New System.Drawing.Size(1043, 730)
        Me.Controls.Add(Me.SimpleButton15)
        Me.Controls.Add(Me.SimpleButton14)
        Me.Controls.Add(Me.SimpleButton13)
        Me.Controls.Add(Me.SimpleButton11)
        Me.Controls.Add(Me.btnXem)
        Me.Controls.Add(Me.btnThem)
        Me.Controls.Add(Me.btnXoa)
        Me.Controls.Add(Me.btnSua)
        Me.Controls.Add(Me.btnDong)
        Me.Controls.Add(Me.GridControl1)
        Me.Controls.Add(Me.barDockControlLeft)
        Me.Controls.Add(Me.barDockControlRight)
        Me.Controls.Add(Me.barDockControlBottom)
        Me.Controls.Add(Me.barDockControlTop)
        Me.MinimumSize = New System.Drawing.Size(1024, 768)
        Me.Name = "Main"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Hau Accounting System 1.0"
        CType(Me.BarManager1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.RepositoryItemButtonEdit1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents BarManager1 As DevExpress.XtraBars.BarManager
    Friend WithEvents Bar1 As DevExpress.XtraBars.Bar
    Friend WithEvents Bar2 As DevExpress.XtraBars.Bar
    Friend WithEvents barDockControlTop As DevExpress.XtraBars.BarDockControl
    Friend WithEvents barDockControlBottom As DevExpress.XtraBars.BarDockControl
    Friend WithEvents barDockControlLeft As DevExpress.XtraBars.BarDockControl
    Friend WithEvents barDockControlRight As DevExpress.XtraBars.BarDockControl
    Friend WithEvents BarSubItem1 As DevExpress.XtraBars.BarSubItem
    Friend WithEvents BarSubItem2 As DevExpress.XtraBars.BarSubItem
    Friend WithEvents BarSubItem3 As DevExpress.XtraBars.BarSubItem
    Friend WithEvents BarSubItem4 As DevExpress.XtraBars.BarSubItem
    Friend WithEvents BarButtonItem1 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarSubItem5 As DevExpress.XtraBars.BarSubItem
    Friend WithEvents BarButtonItem2 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem3 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarEditItem1 As DevExpress.XtraBars.BarEditItem
    Friend WithEvents RepositoryItemButtonEdit1 As DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit
    Friend WithEvents BarButtonItem6 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarSubItem6 As DevExpress.XtraBars.BarSubItem
    Friend WithEvents BarSubItem7 As DevExpress.XtraBars.BarSubItem
    Friend WithEvents BarSubItem8 As DevExpress.XtraBars.BarSubItem
    Friend WithEvents BarButtonItem4 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents GridControl1 As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents BarLargeButtonItem1 As DevExpress.XtraBars.BarLargeButtonItem
    Friend WithEvents btnDong As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton11 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnXem As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnThem As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnXoa As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnSua As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton14 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton13 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton15 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents BarStaticItem1 As DevExpress.XtraBars.BarStaticItem
    Friend WithEvents BarButtonItem9 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem5 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem7 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem8 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem10 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem11 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem12 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem13 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem14 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem15 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem16 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarStaticItem3 As DevExpress.XtraBars.BarStaticItem
    Friend WithEvents BarStaticItem4 As DevExpress.XtraBars.BarStaticItem
    Friend WithEvents BarStaticItem5 As DevExpress.XtraBars.BarStaticItem
    Friend WithEvents BarStaticItem2 As DevExpress.XtraBars.BarStaticItem
    Public WithEvents Bar3 As DevExpress.XtraBars.Bar
    Friend WithEvents BarSubItem9 As DevExpress.XtraBars.BarSubItem
    Friend WithEvents btnBan As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarSubItem10 As DevExpress.XtraBars.BarSubItem
    Friend WithEvents btnKH As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarSubItem11 As DevExpress.XtraBars.BarSubItem
    Friend WithEvents btnKeBanHang As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents btnKeMuaHang As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents btnXNT1 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents btnXNT2 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents btnHangTonKho As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem17 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem18 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents btnNhapChungTu As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem21 As DevExpress.XtraBars.BarButtonItem
    Friend WithEvents BarButtonItem20 As DevExpress.XtraBars.BarButtonItem
End Class
