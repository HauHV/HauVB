﻿Public Class Main
    'Public db = GetAppDBContext()
    'DX FORM
    Private Sub XtraForm2_HandleCreated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.HandleCreated
        DevExpress.Skins.SkinManager.EnableFormSkins()
    End Sub


    Private Sub btnBan_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles btnBan.ItemClick
        'BanHang.Show()
        Using mForm As New BanHang
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub BarButtonItem16_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles BarButtonItem16.ItemClick
        Me.Close()
    End Sub

    Private Sub btnDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDong.Click
        Me.Close()
    End Sub

    Private Sub btnKH_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles btnKH.ItemClick
        'NhapKhachHang.Show()
        Using mForm As New NhapKhachHang
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub btnKeBanHang_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles btnKeBanHang.ItemClick
        'BanHang.Show()
        Using mForm As New BanHang
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub btnKeMuaHang_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles btnKeMuaHang.ItemClick
        'MuaHang.Show()
        '''''
        Using mForm As New MuaHang
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub btnXNT1_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles btnXNT1.ItemClick
        'NXT1.Show()
        Using mForm As New NXT1
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub btnXNT2_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles btnXNT2.ItemClick
        'NXT2.Show()
        Using mForm As New NXT2
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub btnHangTonKho_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles btnHangTonKho.ItemClick
        'HangTonKho.Show()
        Using mForm As New HangTonKho
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub BarButtonItem17_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles BarButtonItem17.ItemClick
        'NhapHang.Show()
        Using mForm As New NhapHang
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub BarButtonItem18_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles BarButtonItem18.ItemClick
        'NhapKho.Show()
        Using mForm As New NhapKho
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub BarButtonItem6_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles BarButtonItem6.ItemClick
        'BanHang.Show()
        Using mForm As New BanHang
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub BarButtonItem9_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles BarButtonItem9.ItemClick
        'MuaHang.Show()
        Using mForm As New MuaHang
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub BarButtonItem10_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles BarButtonItem10.ItemClick
        'NXT1.Show()
        Using mForm As New NXT1
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub BarButtonItem11_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles BarButtonItem11.ItemClick
        'NXT2.Show()
        Using mForm As New NXT2
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub BarButtonItem21_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles BarButtonItem21.ItemClick
        'HangTonKho.Show()
        Using mForm As New HangTonKho
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub

    Private Sub Main_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
        ReadIniFile()
        ConnectDB()
    End Sub

  
    Private Sub btnNhapChungTu_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles btnNhapChungTu.ItemClick
        Using mForm As New NhapChungtu
            mForm.ShowDialog(Me)
            mForm.Dispose()
        End Using
    End Sub
End Class