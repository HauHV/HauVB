﻿Imports System.IO
Imports System.Data.SqlClient
Imports DevExpress.Data.Printing
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.ComponentModel
Imports System.Data.OleDb
Imports DevExpress.XtraReports.UI
Imports DevExpress.LookAndFeel

Public Class NhapKho

    Private Sub NhapKho_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
        RefreshData()
    End Sub

    Private Sub RefreshData()
        Dim db = GetAppDBContext()
        Dim KH = db.Khos.ToList
        GridHang.DataSource = KH
    End Sub
    Private Sub btnThem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnThem.Click
        Using mForm As New NhapKhoForm(NhapKhoForm.eFormMode.Them, Nothing)
            AddHandler mForm.ThemXong, AddressOf RefreshData
            mForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub btnDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDong.Click
        Me.Close()
    End Sub

    Private Sub btnXem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXem.Click
        Using mForm As New NhapKhoForm(NhapKhoForm.eFormMode.Xem, GridView1.GetFocusedRowCellValue("MaKho"))
            mForm.ShowDialog(Me)
        End Using
    End Sub

    Private Sub btnSua_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSua.Click
        Using mForm As New NhapKhoForm(NhapKhoForm.eFormMode.Sua, GridView1.GetFocusedRowCellValue("MaKho"))
            AddHandler mForm.ThemXong, AddressOf RefreshData
            mForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub btnXoa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXoa.Click
        Dim db = GetAppDBContext()
        Dim mData = db.Khos.Where(Function(p) p.MaKho.Equals(GridView1.GetFocusedRowCellValue("MaKho"))).ToList
        MsgBox("Bạn có thực sự muốn xóa?")
        If mData.Count() = 0 Then
            MsgBox("Không có dữ liệu!")
        Else
            db.Khos.DeleteAllOnSubmit(mData)
            db.SubmitChanges()
            RefreshData()
        End If

    End Sub

End Class