﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class NhapChungTuFrm
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.DxErrorProvider1 = New DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider(Me.components)
        Me.btnXoaThayDoi = New DevExpress.XtraEditors.SimpleButton
        Me.btnDong = New DevExpress.XtraEditors.SimpleButton
        Me.btnLuuDong = New DevExpress.XtraEditors.SimpleButton
        Me.btnLuu = New DevExpress.XtraEditors.SimpleButton
        Me.txtLoaiChungTu = New DevExpress.XtraEditors.TextEdit
        Me.txtSoChungTu = New DevExpress.XtraEditors.TextEdit
        Me.txtGhiChu = New DevExpress.XtraEditors.LabelControl
        Me.txtMax = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl4 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl3 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl2 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl1 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl5 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl6 = New DevExpress.XtraEditors.LabelControl
        Me.txtGhiChu1 = New DevExpress.XtraEditors.TextEdit
        Me.txtNgayLap = New DevExpress.XtraEditors.TextEdit
        Me.PopupMenu1 = New DevExpress.XtraBars.PopupMenu(Me.components)
        Me.cboMaKH = New DevExpress.XtraEditors.GridLookUpEdit
        Me.GridLookUpEdit1View = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.cboMaKho = New DevExpress.XtraEditors.GridLookUpEdit
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.cboMaKhoNhan = New DevExpress.XtraEditors.GridLookUpEdit
        Me.GridView2 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.cboMaKhoChuyen = New DevExpress.XtraEditors.GridLookUpEdit
        Me.GridView3 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.GridColumn7 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.GridColumn8 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.GridColumn5 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.GridColumn6 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.GridColumn2 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.GridColumn3 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.GridColumn1 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.GridColumn4 = New DevExpress.XtraGrid.Columns.GridColumn
        CType(Me.DxErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtLoaiChungTu.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtSoChungTu.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGhiChu1.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtNgayLap.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PopupMenu1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboMaKH.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboMaKho.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboMaKhoNhan.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboMaKhoChuyen.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView3, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DxErrorProvider1
        '
        Me.DxErrorProvider1.ContainerControl = Me
        '
        'btnXoaThayDoi
        '
        Me.btnXoaThayDoi.Location = New System.Drawing.Point(34, 328)
        Me.btnXoaThayDoi.Name = "btnXoaThayDoi"
        Me.btnXoaThayDoi.Size = New System.Drawing.Size(97, 23)
        Me.btnXoaThayDoi.TabIndex = 9
        Me.btnXoaThayDoi.Text = "Xóa thay đổi"
        '
        'btnDong
        '
        Me.btnDong.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.btnDong.Appearance.Options.UseFont = True
        Me.btnDong.Location = New System.Drawing.Point(382, 328)
        Me.btnDong.Name = "btnDong"
        Me.btnDong.Size = New System.Drawing.Size(63, 23)
        Me.btnDong.TabIndex = 12
        Me.btnDong.Text = "Đóng"
        '
        'btnLuuDong
        '
        Me.btnLuuDong.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnLuuDong.Appearance.Options.UseFont = True
        Me.btnLuuDong.Location = New System.Drawing.Point(258, 328)
        Me.btnLuuDong.Name = "btnLuuDong"
        Me.btnLuuDong.Size = New System.Drawing.Size(97, 23)
        Me.btnLuuDong.TabIndex = 11
        Me.btnLuuDong.Text = "Lưu và đóng"
        '
        'btnLuu
        '
        Me.btnLuu.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnLuu.Appearance.Options.UseFont = True
        Me.btnLuu.Location = New System.Drawing.Point(155, 328)
        Me.btnLuu.Name = "btnLuu"
        Me.btnLuu.Size = New System.Drawing.Size(75, 23)
        Me.btnLuu.TabIndex = 10
        Me.btnLuu.Text = "Lưu"
        '
        'txtLoaiChungTu
        '
        Me.txtLoaiChungTu.Location = New System.Drawing.Point(135, 72)
        Me.txtLoaiChungTu.Name = "txtLoaiChungTu"
        Me.txtLoaiChungTu.Properties.MaxLength = 50
        Me.txtLoaiChungTu.Size = New System.Drawing.Size(310, 20)
        Me.txtLoaiChungTu.TabIndex = 2
        '
        'txtSoChungTu
        '
        Me.txtSoChungTu.Location = New System.Drawing.Point(135, 37)
        Me.txtSoChungTu.Name = "txtSoChungTu"
        Me.txtSoChungTu.Properties.MaxLength = 50
        Me.txtSoChungTu.Size = New System.Drawing.Size(310, 20)
        Me.txtSoChungTu.TabIndex = 1
        '
        'txtGhiChu
        '
        Me.txtGhiChu.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtGhiChu.Location = New System.Drawing.Point(52, 217)
        Me.txtGhiChu.Name = "txtGhiChu"
        Me.txtGhiChu.Size = New System.Drawing.Size(70, 15)
        Me.txtGhiChu.TabIndex = 5
        Me.txtGhiChu.Text = "Mã kho nhận"
        '
        'txtMax
        '
        Me.txtMax.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.txtMax.Location = New System.Drawing.Point(83, 182)
        Me.txtMax.Name = "txtMax"
        Me.txtMax.Size = New System.Drawing.Size(39, 15)
        Me.txtMax.TabIndex = 4
        Me.txtMax.Text = "Mã kho"
        '
        'LabelControl4
        '
        Me.LabelControl4.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl4.Location = New System.Drawing.Point(39, 147)
        Me.LabelControl4.Name = "LabelControl4"
        Me.LabelControl4.Size = New System.Drawing.Size(83, 15)
        Me.LabelControl4.TabIndex = 3
        Me.LabelControl4.Text = "Mã khách hàng"
        '
        'LabelControl3
        '
        Me.LabelControl3.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl3.Location = New System.Drawing.Point(74, 112)
        Me.LabelControl3.Name = "LabelControl3"
        Me.LabelControl3.Size = New System.Drawing.Size(48, 15)
        Me.LabelControl3.TabIndex = 2
        Me.LabelControl3.Text = "Ngày lập"
        '
        'LabelControl2
        '
        Me.LabelControl2.AllowHtmlString = True
        Me.LabelControl2.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl2.Location = New System.Drawing.Point(36, 77)
        Me.LabelControl2.Name = "LabelControl2"
        Me.LabelControl2.Size = New System.Drawing.Size(86, 15)
        Me.LabelControl2.TabIndex = 1
        Me.LabelControl2.Text = "LoaiChungTu <Color=Red><b> *</b></Color>" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'LabelControl1
        '
        Me.LabelControl1.AllowHtmlString = True
        Me.LabelControl1.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl1.Location = New System.Drawing.Point(48, 42)
        Me.LabelControl1.Name = "LabelControl1"
        Me.LabelControl1.Size = New System.Drawing.Size(74, 15)
        Me.LabelControl1.TabIndex = 0
        Me.LabelControl1.Text = "SoChungTu<Color=Red><b> *</b></Color>"
        '
        'LabelControl5
        '
        Me.LabelControl5.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl5.Location = New System.Drawing.Point(44, 252)
        Me.LabelControl5.Name = "LabelControl5"
        Me.LabelControl5.Size = New System.Drawing.Size(81, 15)
        Me.LabelControl5.TabIndex = 11
        Me.LabelControl5.Text = "Mã kho chuyển"
        '
        'LabelControl6
        '
        Me.LabelControl6.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl6.Location = New System.Drawing.Point(83, 285)
        Me.LabelControl6.Name = "LabelControl6"
        Me.LabelControl6.Size = New System.Drawing.Size(42, 15)
        Me.LabelControl6.TabIndex = 12
        Me.LabelControl6.Text = "Ghi chú"
        '
        'txtGhiChu1
        '
        Me.txtGhiChu1.Location = New System.Drawing.Point(135, 280)
        Me.txtGhiChu1.Name = "txtGhiChu1"
        Me.txtGhiChu1.Properties.MaxLength = 100
        Me.txtGhiChu1.Size = New System.Drawing.Size(308, 20)
        Me.txtGhiChu1.TabIndex = 8
        '
        'txtNgayLap
        '
        Me.txtNgayLap.Location = New System.Drawing.Point(135, 107)
        Me.txtNgayLap.Name = "txtNgayLap"
        Me.txtNgayLap.Properties.DisplayFormat.FormatString = "dd/MM/yyyy"
        Me.txtNgayLap.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime
        Me.txtNgayLap.Properties.EditFormat.FormatString = "dd/MM/yyyy"
        Me.txtNgayLap.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime
        Me.txtNgayLap.Properties.Mask.EditMask = "dd/MM/yyyy"
        Me.txtNgayLap.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret
        Me.txtNgayLap.Properties.MaxLength = 20
        Me.txtNgayLap.Size = New System.Drawing.Size(127, 20)
        Me.txtNgayLap.TabIndex = 3
        '
        'PopupMenu1
        '
        Me.PopupMenu1.Name = "PopupMenu1"
        '
        'cboMaKH
        '
        Me.cboMaKH.EditValue = ""
        Me.cboMaKH.Location = New System.Drawing.Point(135, 142)
        Me.cboMaKH.Name = "cboMaKH"
        Me.cboMaKH.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.cboMaKH.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cboMaKH.Properties.DisplayMember = "MaKH"
        Me.cboMaKH.Properties.NullText = ""
        Me.cboMaKH.Properties.ShowFooter = False
        Me.cboMaKH.Properties.ValueMember = "MaKH"
        Me.cboMaKH.Properties.View = Me.GridLookUpEdit1View
        Me.cboMaKH.Size = New System.Drawing.Size(308, 20)
        Me.cboMaKH.TabIndex = 13
        Me.cboMaKH.Tag = "4"
        '
        'GridLookUpEdit1View
        '
        Me.GridLookUpEdit1View.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.GridColumn1, Me.GridColumn4})
        Me.GridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridLookUpEdit1View.Name = "GridLookUpEdit1View"
        Me.GridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridLookUpEdit1View.OptionsView.ShowGroupPanel = False
        '
        'cboMaKho
        '
        Me.cboMaKho.EditValue = ""
        Me.cboMaKho.Location = New System.Drawing.Point(135, 177)
        Me.cboMaKho.Name = "cboMaKho"
        Me.cboMaKho.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.cboMaKho.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cboMaKho.Properties.DisplayMember = "MaKho"
        Me.cboMaKho.Properties.NullText = ""
        Me.cboMaKho.Properties.ShowFooter = False
        Me.cboMaKho.Properties.ValueMember = "MaKho"
        Me.cboMaKho.Properties.View = Me.GridView1
        Me.cboMaKho.Size = New System.Drawing.Size(308, 20)
        Me.cboMaKho.TabIndex = 14
        Me.cboMaKho.Tag = "5"
        '
        'GridView1
        '
        Me.GridView1.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.GridColumn2, Me.GridColumn3})
        Me.GridView1.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView1.Name = "GridView1"
        Me.GridView1.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView1.OptionsView.ShowGroupPanel = False
        '
        'cboMaKhoNhan
        '
        Me.cboMaKhoNhan.EditValue = ""
        Me.cboMaKhoNhan.Location = New System.Drawing.Point(135, 212)
        Me.cboMaKhoNhan.Name = "cboMaKhoNhan"
        Me.cboMaKhoNhan.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.cboMaKhoNhan.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cboMaKhoNhan.Properties.DisplayMember = "MaKho"
        Me.cboMaKhoNhan.Properties.NullText = ""
        Me.cboMaKhoNhan.Properties.ShowFooter = False
        Me.cboMaKhoNhan.Properties.ValueMember = "MaKho"
        Me.cboMaKhoNhan.Properties.View = Me.GridView2
        Me.cboMaKhoNhan.Size = New System.Drawing.Size(308, 20)
        Me.cboMaKhoNhan.TabIndex = 15
        Me.cboMaKhoNhan.Tag = "6"
        '
        'GridView2
        '
        Me.GridView2.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.GridColumn5, Me.GridColumn6})
        Me.GridView2.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView2.Name = "GridView2"
        Me.GridView2.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView2.OptionsView.ShowGroupPanel = False
        '
        'cboMaKhoChuyen
        '
        Me.cboMaKhoChuyen.EditValue = ""
        Me.cboMaKhoChuyen.Location = New System.Drawing.Point(135, 247)
        Me.cboMaKhoChuyen.Name = "cboMaKhoChuyen"
        Me.cboMaKhoChuyen.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.cboMaKhoChuyen.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cboMaKhoChuyen.Properties.DisplayMember = "MaKho"
        Me.cboMaKhoChuyen.Properties.NullText = ""
        Me.cboMaKhoChuyen.Properties.ShowFooter = False
        Me.cboMaKhoChuyen.Properties.ValueMember = "MaKho"
        Me.cboMaKhoChuyen.Properties.View = Me.GridView3
        Me.cboMaKhoChuyen.Size = New System.Drawing.Size(308, 20)
        Me.cboMaKhoChuyen.TabIndex = 16
        Me.cboMaKhoChuyen.Tag = "7"
        '
        'GridView3
        '
        Me.GridView3.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.GridColumn7, Me.GridColumn8})
        Me.GridView3.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.GridView3.Name = "GridView3"
        Me.GridView3.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.GridView3.OptionsView.ShowGroupPanel = False
        '
        'GridColumn7
        '
        Me.GridColumn7.Caption = "MaKho"
        Me.GridColumn7.FieldName = "MaKho"
        Me.GridColumn7.Name = "GridColumn7"
        Me.GridColumn7.Visible = True
        Me.GridColumn7.VisibleIndex = 0
        Me.GridColumn7.Width = 330
        '
        'GridColumn8
        '
        Me.GridColumn8.Caption = "TenKho"
        Me.GridColumn8.FieldName = "TenKho"
        Me.GridColumn8.Name = "GridColumn8"
        Me.GridColumn8.Visible = True
        Me.GridColumn8.VisibleIndex = 1
        Me.GridColumn8.Width = 636
        '
        'GridColumn5
        '
        Me.GridColumn5.Caption = "MaKho"
        Me.GridColumn5.FieldName = "TenKho"
        Me.GridColumn5.Name = "GridColumn5"
        Me.GridColumn5.Visible = True
        Me.GridColumn5.VisibleIndex = 0
        Me.GridColumn5.Width = 345
        '
        'GridColumn6
        '
        Me.GridColumn6.Caption = "TenKho"
        Me.GridColumn6.FieldName = "TenKho"
        Me.GridColumn6.Name = "GridColumn6"
        Me.GridColumn6.Visible = True
        Me.GridColumn6.VisibleIndex = 1
        Me.GridColumn6.Width = 621
        '
        'GridColumn2
        '
        Me.GridColumn2.Caption = "MaKho"
        Me.GridColumn2.FieldName = "MaKho"
        Me.GridColumn2.Name = "GridColumn2"
        Me.GridColumn2.Visible = True
        Me.GridColumn2.VisibleIndex = 0
        Me.GridColumn2.Width = 352
        '
        'GridColumn3
        '
        Me.GridColumn3.Caption = "TenKho"
        Me.GridColumn3.FieldName = "TenKho"
        Me.GridColumn3.Name = "GridColumn3"
        Me.GridColumn3.Visible = True
        Me.GridColumn3.VisibleIndex = 1
        Me.GridColumn3.Width = 614
        '
        'GridColumn1
        '
        Me.GridColumn1.Caption = "MaKH"
        Me.GridColumn1.FieldName = "MaKH"
        Me.GridColumn1.Name = "GridColumn1"
        Me.GridColumn1.Visible = True
        Me.GridColumn1.VisibleIndex = 0
        Me.GridColumn1.Width = 253
        '
        'GridColumn4
        '
        Me.GridColumn4.Caption = "TenKH"
        Me.GridColumn4.FieldName = "TenKH"
        Me.GridColumn4.Name = "GridColumn4"
        Me.GridColumn4.Visible = True
        Me.GridColumn4.VisibleIndex = 1
        Me.GridColumn4.Width = 713
        '
        'NhapChungTuFrm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(485, 373)
        Me.Controls.Add(Me.cboMaKhoChuyen)
        Me.Controls.Add(Me.cboMaKhoNhan)
        Me.Controls.Add(Me.cboMaKho)
        Me.Controls.Add(Me.cboMaKH)
        Me.Controls.Add(Me.txtGhiChu1)
        Me.Controls.Add(Me.LabelControl6)
        Me.Controls.Add(Me.LabelControl5)
        Me.Controls.Add(Me.txtNgayLap)
        Me.Controls.Add(Me.btnXoaThayDoi)
        Me.Controls.Add(Me.btnDong)
        Me.Controls.Add(Me.btnLuuDong)
        Me.Controls.Add(Me.btnLuu)
        Me.Controls.Add(Me.txtLoaiChungTu)
        Me.Controls.Add(Me.txtSoChungTu)
        Me.Controls.Add(Me.txtGhiChu)
        Me.Controls.Add(Me.txtMax)
        Me.Controls.Add(Me.LabelControl4)
        Me.Controls.Add(Me.LabelControl3)
        Me.Controls.Add(Me.LabelControl2)
        Me.Controls.Add(Me.LabelControl1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "NhapChungTuFrm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Thêm hàng hóa mới"
        CType(Me.DxErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtLoaiChungTu.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtSoChungTu.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGhiChu1.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtNgayLap.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PopupMenu1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboMaKH.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridLookUpEdit1View, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboMaKho.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboMaKhoNhan.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboMaKhoChuyen.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView3, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents DxErrorProvider1 As DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider
    Friend WithEvents btnXoaThayDoi As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnDong As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnLuuDong As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents btnLuu As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents txtLoaiChungTu As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtSoChungTu As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtGhiChu As DevExpress.XtraEditors.LabelControl
    Friend WithEvents txtMax As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl4 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl3 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl2 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl1 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents txtGhiChu1 As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl6 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl5 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents txtNgayLap As DevExpress.XtraEditors.TextEdit
    Friend WithEvents PopupMenu1 As DevExpress.XtraBars.PopupMenu
    Friend WithEvents cboMaKH As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridLookUpEdit1View As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents GridColumn1 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn4 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents cboMaKhoChuyen As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridView3 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents GridColumn7 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn8 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents cboMaKhoNhan As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridView2 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents GridColumn5 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn6 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents cboMaKho As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents GridColumn2 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn3 As DevExpress.XtraGrid.Columns.GridColumn
End Class
