﻿Public Class NhapChungTuFrm
    'Khai báo DataContext


    Private _SoChungTu As String
    Private FormMode As eFormMode
    Public Enum eFormMode
        None = 0
        Them = 1
        Xem = 2
        Sua = 3
    End Enum

    Public Event ThemXong()

    Public Sub New()
        InitializeComponent()
    End Sub
    Public Sub New(ByVal pFormMode As eFormMode, ByVal pSoChungTu As String)
        InitializeComponent()
        FormMode = pFormMode
        _SoChungTu = pSoChungTu
    End Sub
    'Tạo DX form
    Private Sub ThemForm_HandleCreated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.HandleCreated
        DevExpress.Skins.SkinManager.EnableFormSkins()
    End Sub

    'Hàm thêm hàng hóa
    Private Sub ThemFunction()

        If txtSoChungTu.EditValue = "" Or txtLoaiChungTu.EditValue = "" Then
            DxErrorProvider1.SetError(txtSoChungTu, "Dữ liệu không được trống")
            DxErrorProvider1.SetError(txtLoaiChungTu, "Dữ liệu không được trống")
        Else
            Dim anew = New ChungTu
            anew.SoChungTu = txtSoChungTu.EditValue
            anew.LoaiChungTu = txtLoaiChungTu.EditValue
            anew.NgayLap = txtNgayLap.EditValue
            anew.MaKH = cboMaKH.EditValue
            anew.MaKho = cboMaKho.EditValue
            anew.MaKhoNhan = cboMaKhoNhan.EditValue
            anew.MaKhoChuyen = cboMaKhoChuyen.EditValue
            anew.Ghichu = txtGhiChu1.EditValue

            Dim db = GetAppDBContext()
            db.ChungTus.InsertOnSubmit(anew)
            db.SubmitChanges()

            RaiseEvent ThemXong()
        End If

    End Sub

    Private Sub RefreshThemForm()
        txtSoChungTu.EditValue = Nothing
        txtLoaiChungTu.EditValue = "Nhap"
        txtNgayLap.EditValue = Today
        
    End Sub

    Private Sub SuaFunction()
        If txtSoChungTu.EditValue = "" Or txtLoaiChungTu.EditValue = "" Then
            DxErrorProvider1.SetError(txtSoChungTu, "Dữ liệu không được trống")
            DxErrorProvider1.SetError(txtLoaiChungTu, "Dữ liệu không được trống")
        Else
            Dim db = GetAppDBContext()
            Dim mData = db.ChungTus.FirstOrDefault(Function(p) p.SoChungTu.Equals(_SoChungTu))
            With mData

                mData.SoChungTu = txtSoChungTu.EditValue
                mData.LoaiChungTu = txtLoaiChungTu.EditValue
                mData.NgayLap = txtNgayLap.EditValue
                mData.MaKH = cboMaKH.EditValue
                mData.MaKho = cboMaKho.EditValue
                mData.MaKhoNhan = cboMaKhoNhan.EditValue
                mData.MaKhoChuyen = cboMaKhoChuyen.EditValue
                mData.Ghichu = txtGhiChu1.EditValue
            End With

            db.SubmitChanges()
            RaiseEvent ThemXong()
        End If
    End Sub

    Private Sub btnLuu_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLuu.Click

        ThemFunction()
        RefreshThemForm()
    End Sub

    Private Sub btnLuuDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLuuDong.Click
        Select Case FormMode
            Case eFormMode.Them
                ThemFunction()
                Me.Close()
            Case eFormMode.Sua
                SuaFunction()
                Me.Close()
        End Select

    End Sub

    Private Sub btnXoaThayDoi_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXoaThayDoi.Click
        RefreshThemForm()
    End Sub

    Private Sub btnDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDong.Click
        Me.Close()
    End Sub

    Private Sub ThemForm_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        FillCbo()
        Select Case FormMode
            Case eFormMode.Them
                ' nothing
            Case eFormMode.Sua
                Dim db = GetAppDBContext()
                Dim mData = db.ChungTus.FirstOrDefault(Function(p) p.SoChungTu.Equals(_SoChungTu))
                With mData
                    
                    txtSoChungTu.EditValue = mData.SoChungTu
                    txtLoaiChungTu.EditValue = mData.LoaiChungTu
                    txtNgayLap.EditValue = mData.NgayLap
                    cboMaKH.EditValue = mData.MaKH
                    cboMaKho.EditValue = mData.MaKho
                    cboMaKhoNhan.EditValue = mData.MaKhoNhan
                    cboMaKhoChuyen.EditValue = mData.MaKhoChuyen
                    txtGhiChu1.EditValue = mData.Ghichu
                End With
                btnLuu.Visible = False
                'btnLuuDong.Visible = False
                btnXoaThayDoi.Visible = False
            Case eFormMode.Xem
                Dim db = GetAppDBContext()
                Dim mData = db.ChungTus.FirstOrDefault(Function(p) p.SoChungTu.Equals(_SoChungTu))
                With mData
                    txtSoChungTu.EditValue = mData.SoChungTu
                    txtLoaiChungTu.EditValue = mData.LoaiChungTu
                    txtNgayLap.EditValue = mData.NgayLap
                    cboMaKH.EditValue = mData.MaKH
                    cboMaKho.EditValue = mData.MaKho
                    cboMaKhoNhan.EditValue = mData.MaKhoNhan
                    cboMaKhoChuyen.EditValue = mData.MaKhoChuyen
                    txtGhiChu1.EditValue = mData.Ghichu
                End With
                btnLuu.Visible = False
                btnLuuDong.Visible = False
                btnXoaThayDoi.Visible = False
        End Select
    End Sub
    Private Sub FillCbo()
        Dim db = GetAppDBContext()
        Dim KH = db.KHViews.ToList
        cboMaKH.Properties.DataSource = KH
        Dim mKHHeight As Integer = If(KH.Count > 10, 10, KH.Count) * 20 + 27
        cboMaKH.Properties.PopupFormSize = New Size(cboMaKH.Width, mKHHeight)
        cboMaKH.Properties.PopupFormMinSize = New Size(cboMaKH.Width, mKHHeight)

        Dim Kho = db.KhoViews.ToList
        cboMaKho.Properties.DataSource = Kho
        Dim mKhoHeight As Integer = If(Kho.Count > 10, 10, Kho.Count) * 20 + 27
        cboMaKho.Properties.PopupFormSize = New Size(cboMaKho.Width, mKhoHeight)
        cboMaKho.Properties.PopupFormMinSize = New Size(cboMaKho.Width, mKhoHeight)

        cboMaKhoNhan.Properties.DataSource = Kho
        Dim mKhoNhanHeight As Integer = If(Kho.Count > 10, 10, Kho.Count) * 20 + 27
        cboMaKhoNhan.Properties.PopupFormSize = New Size(cboMaKhoNhan.Width, mKhoNhanHeight)
        cboMaKhoNhan.Properties.PopupFormMinSize = New Size(cboMaKhoNhan.Width, mKhoNhanHeight)

        cboMaKhoChuyen.Properties.DataSource = Kho
        Dim mKhoChuyenHeight As Integer = If(Kho.Count > 10, 10, Kho.Count) * 20 + 27
        cboMaKhoChuyen.Properties.PopupFormSize = New Size(cboMaKhoChuyen.Width, mKhoChuyenHeight)
        cboMaKhoChuyen.Properties.PopupFormMinSize = New Size(cboMaKhoChuyen.Width, mKhoChuyenHeight)
    End Sub
End Class