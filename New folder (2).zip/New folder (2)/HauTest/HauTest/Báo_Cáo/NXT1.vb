﻿Imports System.IO
Imports System.Data.SqlClient
Imports DevExpress.Data.Printing
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.ComponentModel
Imports System.Data.OleDb
Imports DevExpress.XtraReports.UI
Imports DevExpress.LookAndFeel

Public Class NXT1

    Private Sub NXT1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
        FillMaKH()
        txtFrom.EditValue = "03/2017"
    End Sub

    Private Sub FillMaKH()
        'Fill Hàng
        Dim db = GetAppDBContext()
        Dim KH = db.HangHoaViews.ToList
        'Edit height cbo
        cboHangFrom.Properties.DataSource = KH
        Dim mHeight As Integer = If(KH.Count > 10, 10, KH.Count) * 19 + 22
        cboHangFrom.Properties.PopupFormSize = New Size(cboHangFrom.Width, mHeight)
        cboHangFrom.Properties.PopupFormMinSize = New Size(cboHangFrom.Width, mHeight)

        cboHangTo.Properties.DataSource = KH
        Dim mHeight2 As Integer = If(KH.Count > 10, 10, KH.Count) * 20 + 27
        cboHangTo.Properties.PopupFormSize = New Size(cboHangTo.Width, mHeight2)
        cboHangTo.Properties.PopupFormMinSize = New Size(cboHangTo.Width, mHeight2)
        'Fill Kho 
        Dim KH2 = db.KhoViews.ToList
        'Edit height cbo
        cboKhoFrom.Properties.DataSource = KH2
        Dim mHeightKho As Integer = If(KH2.Count > 10, 10, KH2.Count) * 20 + 27
        cboKhoFrom.Properties.PopupFormSize = New Size(cboKhoFrom.Width, mHeightKho)
        cboKhoFrom.Properties.PopupFormMinSize = New Size(cboKhoFrom.Width, mHeightKho)

        cboKhoTo.Properties.DataSource = KH2
        Dim mHeightKho2 As Integer = If(KH2.Count > 10, 10, KH2.Count) * 20 + 27
        cboKhoTo.Properties.PopupFormSize = New Size(cboKhoTo.Width, mHeightKho2)
        cboKhoTo.Properties.PopupFormMinSize = New Size(cboKhoTo.Width, mHeightKho2)
    End Sub

    Private Sub TruyVanFunction()
        Dim db = GetAppDBContext()
        Dim fromDate, toDate As New Date
        Dim HangFrom, HangTo As String
        Dim KhoFrom, KhoTo As String

        fromDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue), 1)
        toDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue) + 1, 0)
        HangFrom = cboHangFrom.EditValue
        HangTo = cboHangTo.EditValue
        KhoFrom = cboKhoFrom.EditValue
        KhoTo = cboKhoTo.EditValue
        Dim Hang = db.sp_CanDoiNXT1(fromDate, toDate, HangFrom, HangTo, KhoFrom, KhoTo).ToList
        GridControl1.DataSource = Hang
    End Sub

    Private Sub btnShow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShow.Click
        If txtFrom.EditValue = Nothing Then
            DxErrorProvider1.SetError(txtFrom, "Dữ liệu không được trống")
        Else
            TruyVanFunction()
        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReport.Click
        Dim fromDate, toDate As New Date
        Dim HangFrom, HangTo As String
        Dim KhoFrom, KhoTo As String

        fromDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue), 1)
        toDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue) + 1, 0)
        HangFrom = cboHangFrom.EditValue
        HangTo = cboHangTo.EditValue
        KhoFrom = cboKhoFrom.EditValue
        KhoTo = cboKhoTo.EditValue
        If txtFrom.EditValue = Nothing Then
            DxErrorProvider1.SetError(txtFrom, "Dữ liệu không được trống")
        Else
            Dim db = GetAppDBContext()
            Dim Hang = db.sp_CanDoiNXT1(fromDate, toDate, HangFrom, HangTo, KhoFrom, KhoTo).ToList
            Dim report As New NXT1_Report(fromDate, toDate, HangFrom, HangTo, KhoFrom, KhoTo)

            report.DataSource = Hang

            Dim printTool As New ReportPrintTool(report)
            report.ShowPreview()
        End If
    End Sub

End Class