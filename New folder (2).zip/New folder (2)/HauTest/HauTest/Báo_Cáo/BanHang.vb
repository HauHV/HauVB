﻿Imports System.IO
Imports System.Data.SqlClient
Imports DevExpress.Data.Printing
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.ComponentModel
Imports System.Data.OleDb
Imports DevExpress.XtraReports.UI
Imports DevExpress.LookAndFeel

Public Class BanHang

    Private Sub KeBanHang_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'ReadIniFile()
        'ConnectDB()
        FillMaKH()
        txtFrom.EditValue = "01/03/2017"
        txtTo.EditValue = "31/03/2017"
    End Sub

    Private Sub FillMaKH()
        Dim db = GetAppDBContext()
        Dim KH = db.KHViews.ToList

        cboCusFrom.Properties.DataSource = KH
        Dim mHeight As Integer = If(KH.Count > 10, 10, KH.Count) * 20 + 27
        cboCusFrom.Properties.PopupFormSize = New Size(cboCusFrom.Width, mHeight)
        cboCusFrom.Properties.PopupFormMinSize = New Size(cboCusFrom.Width, mHeight)

        cboCusTo.Properties.DataSource = KH
        Dim mHeight2 As Integer = If(KH.Count > 10, 10, KH.Count) * 20 + 27
        cboCusTo.Properties.PopupFormSize = New Size(cboCusTo.Width, mHeight2)
        cboCusTo.Properties.PopupFormMinSize = New Size(cboCusTo.Width, mHeight2)
    End Sub

    Private Sub TruyVanFunction()
        Dim db = GetAppDBContext()
        Dim fromDate, toDate As New Date
        Dim CusFrom, CusTo As String

        fromDate = txtFrom.EditValue
        toDate = txtTo.EditValue
        CusFrom = cboCusFrom.EditValue
        CusTo = cboCusTo.EditValue
        Dim Hang = db.KeBanHang(fromDate, toDate, CusFrom, CusTo).ToList
        GridControl1.DataSource = Hang
    End Sub

    Private Sub btnShow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShow.Click
        If txtFrom.EditValue = Nothing Or txtTo.EditValue = Nothing Then
            DxErrorProvider1.SetError(txtFrom, "Dữ liệu không được trống")
            DxErrorProvider1.SetError(txtTo, "Dữ liệu không được trống")
        Else
            TruyVanFunction()
        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReport.Click
        Dim fromDate, toDate As New Date
        Dim CusFrom, CusTo As String

        fromDate = txtFrom.EditValue
        toDate = txtTo.EditValue
        CusFrom = cboCusFrom.EditValue
        CusTo = cboCusTo.EditValue
        If txtFrom.EditValue = Nothing Or txtFrom.EditValue = Nothing Then
            DxErrorProvider1.SetError(txtFrom, "Dữ liệu không được trống")
        Else
            Dim db = GetAppDBContext()
            Dim Hang = db.KeBanHang(fromDate, toDate, CusFrom, CusTo).ToList
            Dim report As New BanHangReport(fromDate, toDate, CusFrom, CusTo)

            report.DataSource = Hang

            Dim printTool As New ReportPrintTool(report)
            report.ShowPreview()
        End If
    End Sub
End Class