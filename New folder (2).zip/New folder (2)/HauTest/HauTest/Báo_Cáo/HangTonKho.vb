﻿Imports System.IO
Imports System.Data.SqlClient
Imports DevExpress.Data.Printing
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.ComponentModel
Imports System.Data.OleDb
Imports DevExpress.XtraReports.UI
Imports DevExpress.LookAndFeel

Public Class HangTonKho

    Private Sub HangTonKho_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
        FillMaKH()
        txtTo.EditValue = "31/03/2017"
    End Sub

    Private Sub FillMaKH()
        'Fill Hàng
        Dim db = GetAppDBContext()
        Dim KH = db.HangHoaViews.ToList
        'Edit height cbo
        cboHangFrom.Properties.DataSource = KH
        Dim mHeight As Integer = If(KH.Count > 10, 10, KH.Count) * 20 + 27
        cboHangFrom.Properties.PopupFormSize = New Size(cboHangFrom.Width, mHeight)
        cboHangFrom.Properties.PopupFormMinSize = New Size(cboHangFrom.Width, mHeight)

        cboHangTo.Properties.DataSource = KH
        Dim mHeight2 As Integer = If(KH.Count > 10, 10, KH.Count) * 20 + 27
        cboHangTo.Properties.PopupFormSize = New Size(cboHangTo.Width, mHeight2)
        cboHangTo.Properties.PopupFormMinSize = New Size(cboHangTo.Width, mHeight2)
        'Fill Kho 
        Dim KH2 = db.KhoViews.ToList
        'Edit height cbo
        cboKhoFrom.Properties.DataSource = KH2
        Dim mHeightKho As Integer = If(KH2.Count > 10, 10, KH2.Count) * 20 + 27
        cboKhoFrom.Properties.PopupFormSize = New Size(cboKhoFrom.Width, mHeightKho)
        cboKhoFrom.Properties.PopupFormMinSize = New Size(cboKhoFrom.Width, mHeightKho)

        cboKhoTo.Properties.DataSource = KH2
        Dim mHeightKho2 As Integer = If(KH2.Count > 10, 10, KH2.Count) * 20 + 27
        cboKhoTo.Properties.PopupFormSize = New Size(cboKhoTo.Width, mHeightKho2)
        cboHangTo.Properties.PopupFormMinSize = New Size(cboKhoTo.Width, mHeightKho2)
    End Sub

    Private Sub TruyVanFunction()
        Dim db = GetAppDBContext()
        Dim toDate As New Date
        Dim HangFrom, HangTo As String
        Dim KhoFrom, KhoTo As String

        toDate = txtTo.EditValue
        HangFrom = cboHangFrom.EditValue
        HangTo = cboHangTo.EditValue
        KhoFrom = cboKhoFrom.EditValue
        KhoTo = cboKhoTo.EditValue
        Dim Hang = db.sp_HangHoaTonKho(toDate, HangFrom, HangTo, KhoFrom, KhoTo).ToList
        GridControl1.DataSource = Hang
    End Sub

    Private Sub btnShow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShow.Click
        If txtTo.EditValue = Nothing Then
            DxErrorProvider1.SetError(txtTo, "Dữ liệu không được trống")
        Else
            TruyVanFunction()
        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReport.Click
        Dim toDate As New Date
        Dim HangFrom, HangTo As String
        Dim KhoFrom, KhoTo As String


        toDate = txtTo.EditValue
        HangFrom = cboHangFrom.EditValue
        HangTo = cboHangTo.EditValue
        KhoFrom = cboKhoFrom.EditValue
        KhoTo = cboKhoTo.EditValue
        If txtTo.EditValue = Nothing Then
            DxErrorProvider1.SetError(txtTo, "Dữ liệu không được trống")
        Else
            Dim db = GetAppDBContext()
            Dim Hang = db.sp_HangHoaTonKho(toDate, HangFrom, HangTo, KhoFrom, KhoTo).ToList
            Dim report As New HangTonKho_Report(toDate, HangFrom, HangTo, KhoFrom, KhoTo)

            report.DataSource = Hang

            Dim printTool As New ReportPrintTool(report)
            report.ShowPreview()
        End If
    End Sub

End Class