﻿Imports System.IO
Imports System.Data.SqlClient
Imports DevExpress.Data.Printing
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.ComponentModel
Imports System.Data.OleDb
Imports DevExpress.XtraReports.UI
Imports DevExpress.LookAndFeel

Public Class NXT2

    Private Sub NXT2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        
        FillMaKH()
        txtFrom.EditValue = "03/2017"
    End Sub

    Private Sub FillMaKH()
        Dim db = GetAppDBContext()
        Dim KH = db.HangHoaViews.ToList
        cboCusFrom.Properties.DataSource = KH
        Dim mHeight As Integer = If(KH.Count > 10, 10, KH.Count) * 20 + 27
        cboCusFrom.Properties.PopupFormSize = New Size(cboCusFrom.Width, mHeight)
        cboCusFrom.Properties.PopupFormMinSize = New Size(cboCusFrom.Width, mHeight)

        cboCusTo.Properties.DataSource = KH
        Dim mHeight2 As Integer = If(KH.Count > 10, 10, KH.Count) * 20 + 27
        cboCusTo.Properties.PopupFormSize = New Size(cboCusTo.Width, mHeight2)
        cboCusTo.Properties.PopupFormMinSize = New Size(cboCusTo.Width, mHeight2)
    End Sub

    Private Sub TruyVanFunction()
        Dim db = GetAppDBContext()
        Dim fromDate, toDate As New Date
        Dim CusFrom, CusTo As String

        fromDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue), 1)
        toDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue) + 1, 0)
        CusFrom = cboCusFrom.EditValue
        CusTo = cboCusTo.EditValue
        Dim Hang = db.sp_CanDoiNXT2(fromDate, toDate, CusFrom, CusTo).ToList
        GridControl1.DataSource = Hang
    End Sub

    Private Sub btnShow_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnShow.Click
        If txtFrom.EditValue = Nothing Then
            DxErrorProvider1.SetError(txtFrom, "Dữ liệu không được trống")
        Else
            TruyVanFunction()
        End If
    End Sub

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Private Sub btnReport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnReport.Click
        Dim fromDate, toDate As New Date
        Dim HangFrom, HangTo As String

        fromDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue), 1)
        toDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue) + 1, 0)
        HangFrom = cboCusFrom.EditValue
        HangTo = cboCusTo.EditValue
        If txtFrom.EditValue = Nothing Then
            DxErrorProvider1.SetError(txtFrom, "Dữ liệu không được trống")
        Else
            Dim db = GetAppDBContext()
            Dim Hang = db.sp_CanDoiNXT2(fromDate, toDate, HangFrom, HangTo).ToList
            Dim NXT2report As New NXT2_Report(fromDate, toDate, HangFrom, HangTo)

            NXT2report.DataSource = Hang

            Dim printTool As New ReportPrintTool(NXT2report)
            NXT2report.ShowPreview()
        End If
    End Sub
End Class