﻿Imports System.IO
Imports System.Data.SqlClient
Imports DevExpress.Data.Printing
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.ComponentModel
Imports System.Data.OleDb
Imports DevExpress.XtraReports.UI
Imports DevExpress.LookAndFeel

Public Class HangForm

    Private Sub HangForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'DateEdit1.EditValue = Now.Date
        'DateEdit2.EditValue = Now.Date
        txtFrom.EditValue = Today
        ReadIniFile()
        ConnectDB()
        FillMaKho()
    End Sub

    Private Sub FillMaKho()
        Dim db As New DataClasses1DataContext(ConnectionString)
        Dim Kho = db.viewKho2s.ToList()
        cboLocation.Properties.DataSource = Kho
        Dim mHeight As Integer = If(Kho.Count > 10, 10, Kho.Count) * 19 + 22
        cboLocation.Properties.PopupFormSize = New Size(cboLocation.Width, mHeight)
        cboLocation.Properties.PopupFormMinSize = New Size(cboLocation.Width, mHeight)
    End Sub

    Private Sub TruyVanFunction()
        Dim db As New DataClasses1DataContext(ConnectionString)
        'GridControl1.DataSource = db.HangHoas.ToList()

        'Dim Hang = (From p In db.viewReports Select p).ToList
        'Dim Hang = db.sp_QLyKho(DateSerial(2017, 2, 1), DateSerial(2017, 2, 28)).ToList
        Dim fromDate, toDate As New DateTime
        fromDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue), 1)
        toDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue) + 1, 0)

        Dim Hang = db.sp_CanDoiNXT2(fromDate, toDate, cboLocation.EditValue).ToList
        GridControl1.DataSource = Hang
        'Dim Hang = db.sp_QLyKho3(fromDate, toDate, MaKho).ToList
        'GridControl1.DataSource = Hang
        'Dim Hang = db.HangHoas.Where(Function(p) p.Equals("h1")).ToList
        'GridControl1.DataSource = Hang
    End Sub

    Private Sub btnXem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXem.Click

        If txtFrom.EditValue = Nothing Then
            DxErrorProvider1.SetError(txtFrom, "Dữ liệu không được trống")
            'DxErrorProvider1.SetError(txtTo, "Dữ liệu không được trống")
        Else
            TruyVanFunction()
        End If

    End Sub

    Private Sub SimpleButton2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SimpleButton2.Click
        Me.Close()
    End Sub

    Private Sub SimpleButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SimpleButton1.Click
        GridControl1.DataSource = Nothing
        cboLocation.EditValue = Nothing

    End Sub

    Private Sub DateEdit1_EditValueChanging(ByVal sender As Object, ByVal e As DevExpress.XtraEditors.Controls.ChangingEventArgs)
        DxErrorProvider1.SetError(txtFrom, "")
    End Sub

    Private Sub btnDonGiaVon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDonGiaVon.Click
        GiaVonForm.Show()
    End Sub

    Private Sub Report_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Report.Click
        Dim fromDate, toDate As New DateTime
        If txtFrom.EditValue = Nothing Or txtFrom.EditValue = Nothing Then
            DxErrorProvider1.SetError(txtFrom, "Dữ liệu không được trống")
        Else
            fromDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue), 1)
            toDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue) + 1, 0)
            Dim db As New DataClasses1DataContext(ConnectionString)
            Dim Hang = db.sp_CanDoiNXT2(fromDate, toDate, cboLocation.EditValue).ToList
            Dim report As New XtraReport1(fromDate, toDate)

            report.DataSource = Hang

            Dim printTool As New ReportPrintTool(report)

            report.ShowPreview()
        End If

    End Sub

   
End Class


