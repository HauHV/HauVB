﻿Imports System.Runtime.InteropServices
Imports System.Text
Imports System.ComponentModel

Public Class GiaVonForm

    Private Sub TruyVanFunction()
        Dim db As New DataClasses1DataContext(ConnectionString)
        Dim fromDate, toDate As New DateTime
        fromDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue), 1)
        toDate = DateSerial(Year(txtFrom.EditValue), Month(txtFrom.EditValue) + 1, 0)

        Dim Hang = db.sp_DonGiaVon(fromDate, toDate).ToList
        GridControl1.DataSource = Hang
    End Sub

    Private Sub btnGiaVon_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGiaVon.Click
        If txtFrom.EditValue = Nothing Then
            DxErrorProvider1.SetError(txtFrom, "Dữ liệu không được trống")
        Else
            TruyVanFunction()
        End If
    End Sub

    Private Sub GiaVonForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ReadIniFile()
        ConnectDB()
    End Sub

    Public Sub New()

        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.

    End Sub

    Private _DoiSo As String

    Public Sub New(ByVal pDoiSo As String)
        ' This call is required by the Windows Form Designer.
        InitializeComponent()

        ' Add any initialization after the InitializeComponent() call.
        _DoiSo = pDoiSo
    End Sub

End Class