﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class HangForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Me.GridControl1 = New DevExpress.XtraGrid.GridControl
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.btnXem = New DevExpress.XtraEditors.SimpleButton
        Me.SimpleButton2 = New DevExpress.XtraEditors.SimpleButton
        Me.DxErrorProvider1 = New DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider(Me.components)
        Me.SimpleButton1 = New DevExpress.XtraEditors.SimpleButton
        Me.LabelControl1 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl3 = New DevExpress.XtraEditors.LabelControl
        Me.PopupMenu1 = New DevExpress.XtraBars.PopupMenu(Me.components)
        Me.cboLocation = New DevExpress.XtraEditors.GridLookUpEdit
        Me.cboLocationView = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.GridColumn1 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.GridColumn2 = New DevExpress.XtraGrid.Columns.GridColumn
        Me.txtFrom = New DevExpress.XtraEditors.TextEdit
        Me.btnDonGiaVon = New DevExpress.XtraEditors.SimpleButton
        Me.Report = New DevExpress.XtraEditors.SimpleButton
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DxErrorProvider1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PopupMenu1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboLocation.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.cboLocationView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtFrom.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'GridControl1
        '
        Me.GridControl1.Anchor = CType((((System.Windows.Forms.AnchorStyles.Top Or System.Windows.Forms.AnchorStyles.Bottom) _
                    Or System.Windows.Forms.AnchorStyles.Left) _
                    Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.GridControl1.Location = New System.Drawing.Point(0, 68)
        Me.GridControl1.MainView = Me.GridView1
        Me.GridControl1.Name = "GridControl1"
        Me.GridControl1.Size = New System.Drawing.Size(1038, 445)
        Me.GridControl1.TabIndex = 0
        Me.GridControl1.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.Appearance.EvenRow.BackColor2 = System.Drawing.Color.LightBlue
        Me.GridView1.Appearance.FixedLine.Options.UseTextOptions = True
        Me.GridView1.Appearance.FixedLine.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView1.Appearance.FocusedRow.Options.UseTextOptions = True
        Me.GridView1.Appearance.FocusedRow.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView1.Appearance.Row.Options.UseTextOptions = True
        Me.GridView1.Appearance.Row.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.GridView1.GridControl = Me.GridControl1
        Me.GridView1.Name = "GridView1"
        '
        'btnXem
        '
        Me.btnXem.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnXem.Appearance.Options.UseFont = True
        Me.btnXem.Image = Global.Kho.My.Resources.Resources.iItemList09_16
        Me.btnXem.Location = New System.Drawing.Point(533, 21)
        Me.btnXem.Name = "btnXem"
        Me.btnXem.Size = New System.Drawing.Size(75, 23)
        Me.btnXem.TabIndex = 7
        Me.btnXem.Text = "Xem"
        '
        'SimpleButton2
        '
        Me.SimpleButton2.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Right), System.Windows.Forms.AnchorStyles)
        Me.SimpleButton2.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SimpleButton2.Appearance.Options.UseFont = True
        Me.SimpleButton2.Image = Global.Kho.My.Resources.Resources.iItemX01_161
        Me.SimpleButton2.Location = New System.Drawing.Point(956, 519)
        Me.SimpleButton2.Name = "SimpleButton2"
        Me.SimpleButton2.Size = New System.Drawing.Size(75, 23)
        Me.SimpleButton2.TabIndex = 8
        Me.SimpleButton2.Text = "Close"
        '
        'DxErrorProvider1
        '
        Me.DxErrorProvider1.ContainerControl = Me
        '
        'SimpleButton1
        '
        Me.SimpleButton1.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.SimpleButton1.Appearance.Options.UseFont = True
        Me.SimpleButton1.Image = Global.Kho.My.Resources.Resources.CMD_REFRESH03
        Me.SimpleButton1.Location = New System.Drawing.Point(621, 21)
        Me.SimpleButton1.Name = "SimpleButton1"
        Me.SimpleButton1.Size = New System.Drawing.Size(75, 23)
        Me.SimpleButton1.TabIndex = 9
        Me.SimpleButton1.Text = "Refresh"
        '
        'LabelControl1
        '
        Me.LabelControl1.AllowHtmlString = True
        Me.LabelControl1.AllowHtmlTextInToolTip = DevExpress.Utils.DefaultBoolean.[True]
        Me.LabelControl1.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl1.Location = New System.Drawing.Point(11, 26)
        Me.LabelControl1.Name = "LabelControl1"
        Me.LabelControl1.Size = New System.Drawing.Size(46, 15)
        Me.LabelControl1.TabIndex = 10
        Me.LabelControl1.Text = "Tháng: <Color=Red><b>*</b></Color>"
        '
        'LabelControl3
        '
        Me.LabelControl3.AllowHtmlString = True
        Me.LabelControl3.AllowHtmlTextInToolTip = DevExpress.Utils.DefaultBoolean.[True]
        Me.LabelControl3.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl3.Location = New System.Drawing.Point(251, 25)
        Me.LabelControl3.Name = "LabelControl3"
        Me.LabelControl3.Size = New System.Drawing.Size(45, 15)
        Me.LabelControl3.TabIndex = 12
        Me.LabelControl3.Text = "Mã Kho:"
        '
        'PopupMenu1
        '
        Me.PopupMenu1.Name = "PopupMenu1"
        '
        'cboLocation
        '
        Me.cboLocation.AllowDrop = True
        Me.cboLocation.Cursor = System.Windows.Forms.Cursors.Arrow
        Me.cboLocation.Location = New System.Drawing.Point(305, 22)
        Me.cboLocation.Name = "cboLocation"
        Me.cboLocation.Properties.AllowNullInput = DevExpress.Utils.DefaultBoolean.[True]
        Me.cboLocation.Properties.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.cboLocation.Properties.Appearance.Options.UseFont = True
        Me.cboLocation.Properties.AutoComplete = False
        Me.cboLocation.Properties.AutoHeight = False
        Me.cboLocation.Properties.BestFitMode = DevExpress.XtraEditors.Controls.BestFitMode.BestFit
        Me.cboLocation.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.cboLocation.Properties.DisplayMember = "MaTenKho"
        Me.cboLocation.Properties.ImmediatePopup = True
        Me.cboLocation.Properties.LookAndFeel.Style = DevExpress.LookAndFeel.LookAndFeelStyle.Flat
        Me.cboLocation.Properties.NullText = ""
        Me.cboLocation.Properties.PopupFilterMode = DevExpress.XtraEditors.PopupFilterMode.Contains
        Me.cboLocation.Properties.PopupFormSize = New System.Drawing.Size(334, 50)
        Me.cboLocation.Properties.PopupSizeable = False
        Me.cboLocation.Properties.ShowFooter = False
        Me.cboLocation.Properties.ShowPopupShadow = False
        Me.cboLocation.Properties.ValueMember = "MaKho"
        Me.cboLocation.Properties.View = Me.cboLocationView
        Me.cboLocation.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.cboLocation.ShowToolTips = False
        Me.cboLocation.Size = New System.Drawing.Size(205, 21)
        Me.cboLocation.TabIndex = 15
        Me.cboLocation.TabStop = False
        '
        'cboLocationView
        '
        Me.cboLocationView.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.GridColumn1, Me.GridColumn2})
        Me.cboLocationView.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus
        Me.cboLocationView.Name = "cboLocationView"
        Me.cboLocationView.OptionsBehavior.AutoPopulateColumns = False
        Me.cboLocationView.OptionsSelection.EnableAppearanceFocusedCell = False
        Me.cboLocationView.OptionsView.ShowAutoFilterRow = True
        Me.cboLocationView.OptionsView.ShowColumnHeaders = False
        Me.cboLocationView.OptionsView.ShowGroupPanel = False
        Me.cboLocationView.OptionsView.ShowIndicator = False
        Me.cboLocationView.SortInfo.AddRange(New DevExpress.XtraGrid.Columns.GridColumnSortInfo() {New DevExpress.XtraGrid.Columns.GridColumnSortInfo(Me.GridColumn2, DevExpress.Data.ColumnSortOrder.Ascending)})
        '
        'GridColumn1
        '
        Me.GridColumn1.Caption = "Kho"
        Me.GridColumn1.FieldName = "MakHo"
        Me.GridColumn1.Name = "GridColumn1"
        Me.GridColumn1.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        '
        'GridColumn2
        '
        Me.GridColumn2.AppearanceCell.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.GridColumn2.AppearanceCell.Options.UseFont = True
        Me.GridColumn2.Caption = "Kho"
        Me.GridColumn2.FieldName = "MaTenKho"
        Me.GridColumn2.Name = "GridColumn2"
        Me.GridColumn2.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains
        Me.GridColumn2.SortMode = DevExpress.XtraGrid.ColumnSortMode.Value
        Me.GridColumn2.Visible = True
        Me.GridColumn2.VisibleIndex = 0
        '
        'txtFrom
        '
        Me.txtFrom.EnterMoveNextControl = True
        Me.txtFrom.Location = New System.Drawing.Point(57, 23)
        Me.txtFrom.Name = "txtFrom"
        Me.txtFrom.Properties.Appearance.Options.UseTextOptions = True
        Me.txtFrom.Properties.Appearance.TextOptions.HAlignment = DevExpress.Utils.HorzAlignment.Center
        Me.txtFrom.Properties.DisplayFormat.FormatString = "MM/yyyy"
        Me.txtFrom.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.DateTime
        Me.txtFrom.Properties.EditFormat.FormatString = "MM/yyyy"
        Me.txtFrom.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.DateTime
        Me.txtFrom.Properties.Mask.EditMask = "MM/yyyy"
        Me.txtFrom.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret
        Me.txtFrom.Size = New System.Drawing.Size(178, 20)
        Me.txtFrom.TabIndex = 16
        '
        'btnDonGiaVon
        '
        Me.btnDonGiaVon.AllowDrop = True
        Me.btnDonGiaVon.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.btnDonGiaVon.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.btnDonGiaVon.Appearance.Options.UseFont = True
        Me.btnDonGiaVon.Image = Global.Kho.My.Resources.Resources.iItemList09_16
        Me.btnDonGiaVon.Location = New System.Drawing.Point(86, 519)
        Me.btnDonGiaVon.Name = "btnDonGiaVon"
        Me.btnDonGiaVon.Size = New System.Drawing.Size(110, 23)
        Me.btnDonGiaVon.TabIndex = 18
        Me.btnDonGiaVon.Text = "Đơn Giá Vốn"
        '
        'Report
        '
        Me.Report.Anchor = CType((System.Windows.Forms.AnchorStyles.Bottom Or System.Windows.Forms.AnchorStyles.Left), System.Windows.Forms.AnchorStyles)
        Me.Report.Image = Global.Kho.My.Resources.Resources.CMD_PREVIEW02
        Me.Report.Location = New System.Drawing.Point(5, 519)
        Me.Report.Name = "Report"
        Me.Report.Size = New System.Drawing.Size(75, 23)
        Me.Report.TabIndex = 19
        Me.Report.Text = "Report"
        '
        'HangForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1038, 554)
        Me.Controls.Add(Me.Report)
        Me.Controls.Add(Me.btnDonGiaVon)
        Me.Controls.Add(Me.txtFrom)
        Me.Controls.Add(Me.cboLocation)
        Me.Controls.Add(Me.LabelControl3)
        Me.Controls.Add(Me.LabelControl1)
        Me.Controls.Add(Me.SimpleButton1)
        Me.Controls.Add(Me.SimpleButton2)
        Me.Controls.Add(Me.btnXem)
        Me.Controls.Add(Me.GridControl1)
        Me.Name = "HangForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Quản Lý Nhập Xuất"
        CType(Me.GridControl1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DxErrorProvider1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PopupMenu1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboLocation.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.cboLocationView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtFrom.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GridControl1 As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents btnXem As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents SimpleButton2 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents DxErrorProvider1 As DevExpress.XtraEditors.DXErrorProvider.DXErrorProvider
    Friend WithEvents SimpleButton1 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents LabelControl1 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl3 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents PopupMenu1 As DevExpress.XtraBars.PopupMenu
    Friend WithEvents cboLocation As DevExpress.XtraEditors.GridLookUpEdit
    Friend WithEvents cboLocationView As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents GridColumn1 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents GridColumn2 As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents txtFrom As DevExpress.XtraEditors.TextEdit
    Friend WithEvents btnDonGiaVon As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents Report As DevExpress.XtraEditors.SimpleButton

End Class
