﻿Imports System.IO
Imports System.Data.SqlClient
Imports DevExpress.Data.Printing
Imports System.Runtime.InteropServices
Imports System.Text
Imports System.ComponentModel

Module Module1

    Public SQLDatabase As String
    Public SQLServer As String
    Public UserID As String
    Public Password As String
    Public ConnectionString As String

    Public Declare Auto Function GetPrivateProfileString Lib "kernel32" (ByVal lpAppName As String, _
      ByVal lpKeyName As String, _
      ByVal lpDefault As String, _
      ByVal lpReturnedString As StringBuilder, _
      ByVal nSize As Integer, _
      ByVal lpFileName As String) As Integer

    Sub ReadIniFile()
        Dim res As Integer
        Dim server As StringBuilder
        Dim database As StringBuilder
        Dim user As StringBuilder
        Dim pass As StringBuilder

        server = New StringBuilder(500)
        database = New StringBuilder(500)
        user = New StringBuilder(500)
        pass = New StringBuilder(500)

        res = GetPrivateProfileString("SystemConfig", "SQLServer", "", server, server.Capacity, My.Application.Info.DirectoryPath & "\AppConfig.INI")
        res = GetPrivateProfileString("SystemConfig", "SQLDatabase", "", database, database.Capacity, My.Application.Info.DirectoryPath & "\AppConfig.INI")
        res = GetPrivateProfileString("SystemConfig", "User", "", user, user.Capacity, My.Application.Info.DirectoryPath & "\AppConfig.INI")
        res = GetPrivateProfileString("SystemConfig", "Password", "", pass, pass.Capacity, My.Application.Info.DirectoryPath & "\AppConfig.INI")

        SQLServer = server.ToString()
        SQLDatabase = database.ToString()
        UserID = user.ToString()
        Password = pass.ToString()

    End Sub

    Sub ConnectDB()
        ConnectionString = "data source=" & SQLServer & ";" & _
        "initial catalog=" & SQLDatabase & ";" & _
        "User Id=" & UserID & "; password=" & Password & ";"

    End Sub

End Module
