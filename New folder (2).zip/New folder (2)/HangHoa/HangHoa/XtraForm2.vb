﻿Public Class XtraForm2 
    'DX FORM
    Private Sub XtraForm2_HandleCreated(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.HandleCreated
        DevExpress.Skins.SkinManager.EnableFormSkins()
    End Sub
    'Đổ dữ liệu vào Grid
    Private Sub RefreshData()
        Dim db As New database1DataContext
        GridControl1.DataSource = db.tblHangHoas.ToList()
    End Sub

    Private Sub XtraForm2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        RefreshData()
    End Sub

    Private Sub BarButtonItem16_ItemClick(ByVal sender As System.Object, ByVal e As DevExpress.XtraBars.ItemClickEventArgs) Handles BarButtonItem16.ItemClick
        Me.Close()
    End Sub

    Private Sub btnThem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnThem.Click
        Using mForm As New ThemForm(ThemForm.eFormMode.Them, Nothing)
            AddHandler mForm.ThemXong, AddressOf RefreshData
            mForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub btnDong_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDong.Click
        Me.Close()
    End Sub

    Private Sub btnXem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXem.Click
        Using mForm As New ThemForm(ThemForm.eFormMode.Xem, GridView1.GetFocusedRowCellValue("MaHang"))
            mForm.ShowDialog(Me)
        End Using
    End Sub

    Private Sub btnSua_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSua.Click
        Using mForm As New ThemForm(ThemForm.eFormMode.Sua, GridView1.GetFocusedRowCellValue("MaHang"))
            AddHandler mForm.ThemXong, AddressOf RefreshData
            mForm.ShowDialog(Me)
        End Using

    End Sub

    Private Sub btnXoa_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnXoa.Click
        Dim db = New database1DataContext
        Dim mData = db.tblHangHoas.Where(Function(p) p.MaHang.Equals(GridView1.GetFocusedRowCellValue("MaHang"))).ToList
        db.tblHangHoas.DeleteAllOnSubmit(mData)
        db.SubmitChanges()
        RefreshData()
    End Sub

End Class