﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class XemForm
    Inherits DevExpress.XtraEditors.XtraForm

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtGiaBan1 = New DevExpress.XtraEditors.TextEdit
        Me.txtHangTon = New DevExpress.XtraEditors.TextEdit
        Me.SimpleButton3 = New DevExpress.XtraEditors.SimpleButton
        Me.NgayTao = New DevExpress.XtraEditors.DateEdit
        Me.txtGiaBan2 = New DevExpress.XtraEditors.TextEdit
        Me.txtTenHang = New DevExpress.XtraEditors.TextEdit
        Me.txtMaHang = New DevExpress.XtraEditors.TextEdit
        Me.LabelControl6 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl5 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl4 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl3 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl2 = New DevExpress.XtraEditors.LabelControl
        Me.LabelControl1 = New DevExpress.XtraEditors.LabelControl
        CType(Me.txtGiaBan1.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtHangTon.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NgayTao.Properties.VistaTimeProperties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.NgayTao.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtGiaBan2.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtTenHang.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.txtMaHang.Properties, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtGiaBan1
        '
        Me.txtGiaBan1.Location = New System.Drawing.Point(119, 136)
        Me.txtGiaBan1.Name = "txtGiaBan1"
        Me.txtGiaBan1.Properties.Mask.EditMask = "n2"
        Me.txtGiaBan1.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtGiaBan1.Size = New System.Drawing.Size(181, 20)
        Me.txtGiaBan1.TabIndex = 33
        '
        'txtHangTon
        '
        Me.txtHangTon.Location = New System.Drawing.Point(119, 104)
        Me.txtHangTon.Name = "txtHangTon"
        Me.txtHangTon.Properties.Mask.EditMask = "n0"
        Me.txtHangTon.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtHangTon.Size = New System.Drawing.Size(109, 20)
        Me.txtHangTon.TabIndex = 32
        '
        'SimpleButton3
        '
        Me.SimpleButton3.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(178, Byte))
        Me.SimpleButton3.Appearance.Options.UseFont = True
        Me.SimpleButton3.Image = Global.HangHoa.My.Resources.Resources.CMD_EXIT01
        Me.SimpleButton3.Location = New System.Drawing.Point(318, 245)
        Me.SimpleButton3.Name = "SimpleButton3"
        Me.SimpleButton3.Size = New System.Drawing.Size(63, 23)
        Me.SimpleButton3.TabIndex = 30
        Me.SimpleButton3.Text = "Đóng"
        '
        'NgayTao
        '
        Me.NgayTao.EditValue = Nothing
        Me.NgayTao.Location = New System.Drawing.Point(119, 194)
        Me.NgayTao.Name = "NgayTao"
        Me.NgayTao.Properties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)})
        Me.NgayTao.Properties.Mask.EditMask = "dd/mm/yyyy"
        Me.NgayTao.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.DateTimeAdvancingCaret
        Me.NgayTao.Properties.VistaTimeProperties.Buttons.AddRange(New DevExpress.XtraEditors.Controls.EditorButton() {New DevExpress.XtraEditors.Controls.EditorButton})
        Me.NgayTao.Size = New System.Drawing.Size(109, 20)
        Me.NgayTao.TabIndex = 27
        '
        'txtGiaBan2
        '
        Me.txtGiaBan2.Location = New System.Drawing.Point(119, 165)
        Me.txtGiaBan2.Name = "txtGiaBan2"
        Me.txtGiaBan2.Properties.Mask.EditMask = "N2"
        Me.txtGiaBan2.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.Numeric
        Me.txtGiaBan2.Size = New System.Drawing.Size(181, 20)
        Me.txtGiaBan2.TabIndex = 26
        '
        'txtTenHang
        '
        Me.txtTenHang.Location = New System.Drawing.Point(119, 78)
        Me.txtTenHang.Name = "txtTenHang"
        Me.txtTenHang.Properties.Mask.EditMask = ".+"
        Me.txtTenHang.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx
        Me.txtTenHang.Size = New System.Drawing.Size(181, 20)
        Me.txtTenHang.TabIndex = 25
        '
        'txtMaHang
        '
        Me.txtMaHang.Location = New System.Drawing.Point(119, 51)
        Me.txtMaHang.Name = "txtMaHang"
        Me.txtMaHang.Properties.Mask.EditMask = ".+"
        Me.txtMaHang.Properties.Mask.MaskType = DevExpress.XtraEditors.Mask.MaskType.RegEx
        Me.txtMaHang.Size = New System.Drawing.Size(181, 20)
        Me.txtMaHang.TabIndex = 24
        '
        'LabelControl6
        '
        Me.LabelControl6.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl6.Location = New System.Drawing.Point(53, 196)
        Me.LabelControl6.Name = "LabelControl6"
        Me.LabelControl6.Size = New System.Drawing.Size(52, 15)
        Me.LabelControl6.TabIndex = 23
        Me.LabelControl6.Text = "Ngày Tạo"
        '
        'LabelControl5
        '
        Me.LabelControl5.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl5.Location = New System.Drawing.Point(53, 167)
        Me.LabelControl5.Name = "LabelControl5"
        Me.LabelControl5.Size = New System.Drawing.Size(54, 15)
        Me.LabelControl5.TabIndex = 22
        Me.LabelControl5.Text = "Giá Bán 2"
        '
        'LabelControl4
        '
        Me.LabelControl4.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl4.Location = New System.Drawing.Point(53, 138)
        Me.LabelControl4.Name = "LabelControl4"
        Me.LabelControl4.Size = New System.Drawing.Size(54, 15)
        Me.LabelControl4.TabIndex = 21
        Me.LabelControl4.Text = "Giá Bán 1"
        '
        'LabelControl3
        '
        Me.LabelControl3.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl3.Location = New System.Drawing.Point(53, 109)
        Me.LabelControl3.Name = "LabelControl3"
        Me.LabelControl3.Size = New System.Drawing.Size(57, 15)
        Me.LabelControl3.TabIndex = 20
        Me.LabelControl3.Text = "Hàng Tồn "
        '
        'LabelControl2
        '
        Me.LabelControl2.AllowHtmlString = True
        Me.LabelControl2.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl2.Location = New System.Drawing.Point(53, 80)
        Me.LabelControl2.Name = "LabelControl2"
        Me.LabelControl2.Size = New System.Drawing.Size(65, 15)
        Me.LabelControl2.TabIndex = 19
        Me.LabelControl2.Text = "Tên Hàng <Color=Red><b> *</b></Color>" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'LabelControl1
        '
        Me.LabelControl1.AllowHtmlString = True
        Me.LabelControl1.Appearance.Font = New System.Drawing.Font("Arial", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(163, Byte))
        Me.LabelControl1.Location = New System.Drawing.Point(53, 51)
        Me.LabelControl1.Name = "LabelControl1"
        Me.LabelControl1.Size = New System.Drawing.Size(57, 15)
        Me.LabelControl1.TabIndex = 18
        Me.LabelControl1.Text = "Mã Hàng<Color=Red><b> *</b></Color>"
        '
        'XemForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(393, 280)
        Me.Controls.Add(Me.txtGiaBan1)
        Me.Controls.Add(Me.txtHangTon)
        Me.Controls.Add(Me.SimpleButton3)
        Me.Controls.Add(Me.NgayTao)
        Me.Controls.Add(Me.txtGiaBan2)
        Me.Controls.Add(Me.txtTenHang)
        Me.Controls.Add(Me.txtMaHang)
        Me.Controls.Add(Me.LabelControl6)
        Me.Controls.Add(Me.LabelControl5)
        Me.Controls.Add(Me.LabelControl4)
        Me.Controls.Add(Me.LabelControl3)
        Me.Controls.Add(Me.LabelControl2)
        Me.Controls.Add(Me.LabelControl1)
        Me.Name = "XemForm"
        Me.Text = "XemForm"
        CType(Me.txtGiaBan1.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtHangTon.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NgayTao.Properties.VistaTimeProperties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.NgayTao.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtGiaBan2.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtTenHang.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.txtMaHang.Properties, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents txtGiaBan1 As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtHangTon As DevExpress.XtraEditors.TextEdit
    Friend WithEvents SimpleButton3 As DevExpress.XtraEditors.SimpleButton
    Friend WithEvents NgayTao As DevExpress.XtraEditors.DateEdit
    Friend WithEvents txtGiaBan2 As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtTenHang As DevExpress.XtraEditors.TextEdit
    Friend WithEvents txtMaHang As DevExpress.XtraEditors.TextEdit
    Friend WithEvents LabelControl6 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl5 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl4 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl3 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl2 As DevExpress.XtraEditors.LabelControl
    Friend WithEvents LabelControl1 As DevExpress.XtraEditors.LabelControl
End Class
