﻿Public Class FormLinQ
    



    Private Sub FormLinQ_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim database As New DataClasses1DataContext

        GridControl1.DataSource = database.Khachhangs.ToList


    End Sub
End Class