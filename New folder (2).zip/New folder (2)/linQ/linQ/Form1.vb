﻿Imports System.Text
Imports System.Windows.Forms
Imports System.Collections
Imports System.Linq

Public Class Form1

    Private Sub btnLinQ_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLinQ.Click
        FormLinQ.Show()

    End Sub
End Class
