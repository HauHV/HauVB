﻿Public Class Form2

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'QuanLyBanHangDataSet1.Khachhang' table. You can move, or remove it, as needed.
        Me.KhachhangTableAdapter.Fill(Me.QuanLyBanHangDataSet1.Khachhang)

    End Sub
End Class