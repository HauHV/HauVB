﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.QuanLyBanHangDataSet1 = New Day2.QuanLyBanHangDataSet1
        Me.KhachhangBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.KhachhangTableAdapter = New Day2.QuanLyBanHangDataSet1TableAdapters.KhachhangTableAdapter
        Me.TableAdapterManager = New Day2.QuanLyBanHangDataSet1TableAdapters.TableAdapterManager
        Me.KhachhangBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton
        Me.KhachhangBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton
        Me.KhachhangGridControl = New DevExpress.XtraGrid.GridControl
        Me.GridView1 = New DevExpress.XtraGrid.Views.Grid.GridView
        Me.colKhachHangID = New DevExpress.XtraGrid.Columns.GridColumn
        Me.colKhachHang = New DevExpress.XtraGrid.Columns.GridColumn
        Me.colDiachi = New DevExpress.XtraGrid.Columns.GridColumn
        Me.colNgaysinh = New DevExpress.XtraGrid.Columns.GridColumn
        Me.colGioitinh = New DevExpress.XtraGrid.Columns.GridColumn
        Me.DataGridView1 = New System.Windows.Forms.DataGridView
        Me.KhachHangIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.KhachHangDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.DiachiDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.NgaysinhDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn
        Me.GioitinhDataGridViewCheckBoxColumn = New System.Windows.Forms.DataGridViewCheckBoxColumn
        CType(Me.QuanLyBanHangDataSet1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.KhachhangBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.KhachhangBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.KhachhangBindingNavigator.SuspendLayout()
        CType(Me.KhachhangGridControl, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'QuanLyBanHangDataSet1
        '
        Me.QuanLyBanHangDataSet1.DataSetName = "QuanLyBanHangDataSet1"
        Me.QuanLyBanHangDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'KhachhangBindingSource
        '
        Me.KhachhangBindingSource.DataMember = "Khachhang"
        Me.KhachhangBindingSource.DataSource = Me.QuanLyBanHangDataSet1
        '
        'KhachhangTableAdapter
        '
        Me.KhachhangTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.KhachhangTableAdapter = Me.KhachhangTableAdapter
        Me.TableAdapterManager.UpdateOrder = Day2.QuanLyBanHangDataSet1TableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'KhachhangBindingNavigator
        '
        Me.KhachhangBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.KhachhangBindingNavigator.BindingSource = Me.KhachhangBindingSource
        Me.KhachhangBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.KhachhangBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.KhachhangBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.KhachhangBindingNavigatorSaveItem})
        Me.KhachhangBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.KhachhangBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.KhachhangBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.KhachhangBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.KhachhangBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.KhachhangBindingNavigator.Name = "KhachhangBindingNavigator"
        Me.KhachhangBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.KhachhangBindingNavigator.Size = New System.Drawing.Size(604, 25)
        Me.KhachhangBindingNavigator.TabIndex = 0
        Me.KhachhangBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 15)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 6)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 6)
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 20)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'KhachhangBindingNavigatorSaveItem
        '
        Me.KhachhangBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.KhachhangBindingNavigatorSaveItem.Image = CType(resources.GetObject("KhachhangBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.KhachhangBindingNavigatorSaveItem.Name = "KhachhangBindingNavigatorSaveItem"
        Me.KhachhangBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 23)
        Me.KhachhangBindingNavigatorSaveItem.Text = "Save Data"
        '
        'KhachhangGridControl
        '
        Me.KhachhangGridControl.DataSource = Me.KhachhangBindingSource
        Me.KhachhangGridControl.Location = New System.Drawing.Point(50, 57)
        Me.KhachhangGridControl.MainView = Me.GridView1
        Me.KhachhangGridControl.Name = "KhachhangGridControl"
        Me.KhachhangGridControl.Size = New System.Drawing.Size(395, 282)
        Me.KhachhangGridControl.TabIndex = 1
        Me.KhachhangGridControl.ViewCollection.AddRange(New DevExpress.XtraGrid.Views.Base.BaseView() {Me.GridView1})
        '
        'GridView1
        '
        Me.GridView1.Columns.AddRange(New DevExpress.XtraGrid.Columns.GridColumn() {Me.colKhachHangID, Me.colKhachHang, Me.colDiachi, Me.colNgaysinh, Me.colGioitinh})
        Me.GridView1.GridControl = Me.KhachhangGridControl
        Me.GridView1.Name = "GridView1"
        '
        'colKhachHangID
        '
        Me.colKhachHangID.FieldName = "KhachHangID"
        Me.colKhachHangID.Name = "colKhachHangID"
        Me.colKhachHangID.Visible = True
        Me.colKhachHangID.VisibleIndex = 0
        '
        'colKhachHang
        '
        Me.colKhachHang.FieldName = "KhachHang"
        Me.colKhachHang.Name = "colKhachHang"
        Me.colKhachHang.Visible = True
        Me.colKhachHang.VisibleIndex = 1
        '
        'colDiachi
        '
        Me.colDiachi.FieldName = "Diachi"
        Me.colDiachi.Name = "colDiachi"
        Me.colDiachi.Visible = True
        Me.colDiachi.VisibleIndex = 2
        '
        'colNgaysinh
        '
        Me.colNgaysinh.FieldName = "Ngaysinh"
        Me.colNgaysinh.Name = "colNgaysinh"
        Me.colNgaysinh.Visible = True
        Me.colNgaysinh.VisibleIndex = 3
        '
        'colGioitinh
        '
        Me.colGioitinh.FieldName = "Gioitinh"
        Me.colGioitinh.Name = "colGioitinh"
        Me.colGioitinh.Visible = True
        Me.colGioitinh.VisibleIndex = 4
        '
        'DataGridView1
        '
        Me.DataGridView1.AutoGenerateColumns = False
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.KhachHangIDDataGridViewTextBoxColumn, Me.KhachHangDataGridViewTextBoxColumn, Me.DiachiDataGridViewTextBoxColumn, Me.NgaysinhDataGridViewTextBoxColumn, Me.GioitinhDataGridViewCheckBoxColumn})
        Me.DataGridView1.DataSource = Me.KhachhangBindingSource
        Me.DataGridView1.Location = New System.Drawing.Point(12, 345)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(565, 152)
        Me.DataGridView1.TabIndex = 2
        '
        'KhachHangIDDataGridViewTextBoxColumn
        '
        Me.KhachHangIDDataGridViewTextBoxColumn.DataPropertyName = "KhachHangID"
        Me.KhachHangIDDataGridViewTextBoxColumn.HeaderText = "KhachHangID"
        Me.KhachHangIDDataGridViewTextBoxColumn.Name = "KhachHangIDDataGridViewTextBoxColumn"
        '
        'KhachHangDataGridViewTextBoxColumn
        '
        Me.KhachHangDataGridViewTextBoxColumn.DataPropertyName = "KhachHang"
        Me.KhachHangDataGridViewTextBoxColumn.HeaderText = "KhachHang"
        Me.KhachHangDataGridViewTextBoxColumn.Name = "KhachHangDataGridViewTextBoxColumn"
        '
        'DiachiDataGridViewTextBoxColumn
        '
        Me.DiachiDataGridViewTextBoxColumn.DataPropertyName = "Diachi"
        Me.DiachiDataGridViewTextBoxColumn.HeaderText = "Diachi"
        Me.DiachiDataGridViewTextBoxColumn.Name = "DiachiDataGridViewTextBoxColumn"
        '
        'NgaysinhDataGridViewTextBoxColumn
        '
        Me.NgaysinhDataGridViewTextBoxColumn.DataPropertyName = "Ngaysinh"
        Me.NgaysinhDataGridViewTextBoxColumn.HeaderText = "Ngaysinh"
        Me.NgaysinhDataGridViewTextBoxColumn.Name = "NgaysinhDataGridViewTextBoxColumn"
        '
        'GioitinhDataGridViewCheckBoxColumn
        '
        Me.GioitinhDataGridViewCheckBoxColumn.DataPropertyName = "Gioitinh"
        Me.GioitinhDataGridViewCheckBoxColumn.HeaderText = "Gioitinh"
        Me.GioitinhDataGridViewCheckBoxColumn.Name = "GioitinhDataGridViewCheckBoxColumn"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(604, 529)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.KhachhangGridControl)
        Me.Controls.Add(Me.KhachhangBindingNavigator)
        Me.Name = "Form1"
        Me.Text = "Form1"
        CType(Me.QuanLyBanHangDataSet1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.KhachhangBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.KhachhangBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.KhachhangBindingNavigator.ResumeLayout(False)
        Me.KhachhangBindingNavigator.PerformLayout()
        CType(Me.KhachhangGridControl, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.GridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents QuanLyBanHangDataSet1 As Day2.QuanLyBanHangDataSet1
    Friend WithEvents KhachhangBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents KhachhangTableAdapter As Day2.QuanLyBanHangDataSet1TableAdapters.KhachhangTableAdapter
    Friend WithEvents TableAdapterManager As Day2.QuanLyBanHangDataSet1TableAdapters.TableAdapterManager
    Friend WithEvents KhachhangBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents KhachhangBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents KhachhangGridControl As DevExpress.XtraGrid.GridControl
    Friend WithEvents GridView1 As DevExpress.XtraGrid.Views.Grid.GridView
    Friend WithEvents colKhachHangID As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents colKhachHang As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents colDiachi As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents colNgaysinh As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents colGioitinh As DevExpress.XtraGrid.Columns.GridColumn
    Friend WithEvents DataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents KhachHangIDDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents KhachHangDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DiachiDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents NgaysinhDataGridViewTextBoxColumn As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents GioitinhDataGridViewCheckBoxColumn As System.Windows.Forms.DataGridViewCheckBoxColumn

End Class
